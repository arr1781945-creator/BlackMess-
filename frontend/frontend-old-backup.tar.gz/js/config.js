// API Configuration
const API_CONFIG = {
    BASE_URL: 'http://127.0.0.1:8000',
    WS_URL: 'ws://127.0.0.1:8000',
    API_VERSION: 'v1',
    TIMEOUT: 30000,
};

// API Endpoints
const API_ENDPOINTS = {
    // Auth
    LOGIN: '/api/auth/login/',
    REGISTER: '/api/auth/register/',
    REFRESH_TOKEN: '/api/auth/token/refresh/',
    PROFILE: '/api/auth/profile/',
    CHANGE_PASSWORD: '/api/auth/change-password/',
    
    // Workspaces
    WORKSPACES: '/api/workspaces/',
    WORKSPACE_DETAIL: (id) => `/api/workspaces/${id}/`,
    WORKSPACE_JOIN: (id) => `/api/workspaces/${id}/join/`,
    WORKSPACE_MEMBERS: (id) => `/api/workspaces/${id}/members/`,
    
    // Channels
    CHANNELS: '/api/channels/',
    CHANNEL_DETAIL: (id) => `/api/channels/${id}/`,
    CHANNEL_JOIN: (id) => `/api/channels/${id}/join/`,
    CHANNEL_MEMBERS: (id) => `/api/channels/${id}/members/`,
    
    // Messages
    MESSAGES: '/api/messages/',
    MESSAGE_DETAIL: (id) => `/api/messages/${id}/`,
    MESSAGE_THREAD: (id) => `/api/messages/${id}/thread/`,
    MESSAGE_REACT: (id) => `/api/messages/${id}/react/`,
    MESSAGE_PIN: (id) => `/api/messages/${id}/pin/`,
    
    // Notifications
    NOTIFICATIONS: '/api/notifications/',
    MARK_ALL_READ: '/api/notifications/mark_all_read/',
    
    // Bookmarks
    BOOKMARKS: '/api/bookmarks/',
};

// WebSocket Endpoints
const WS_ENDPOINTS = {
    CHAT: (channelId) => `/ws/chat/${channelId}/`,
    WORKSPACE: (workspaceId) => `/ws/workspace/${workspaceId}/`,
    NOTIFICATIONS: '/ws/notifications/',
};

// Local Storage Keys
const STORAGE_KEYS = {
    ACCESS_TOKEN: 'access_token',
    REFRESH_TOKEN: 'refresh_token',
    USER_DATA: 'user_data',
    CURRENT_WORKSPACE: 'current_workspace',
    CURRENT_CHANNEL: 'current_channel',
    THEME: 'theme',
};

// App State
const APP_STATE = {
    user: null,
    currentWorkspace: null,
    currentChannel: null,
    workspaces: [],
    channels: [],
    messages: [],
    websocket: null,
    isConnected: false,
};

console.log('✅ Config loaded');
