// Thread Manager

class ThreadManager {
    constructor() {
        this.currentThread = null;
        this.isThreadOpen = false;
    }

    // Open thread
    async openThread(messageId) {
        showLoading(true);
        
        try {
            const response = await api.get(`/api/threads/${messageId}/`);
            
            this.currentThread = response;
            this.isThreadOpen = true;
            
            // Show right sidebar
            this.showThreadSidebar(response);
            
        } catch (error) {
            console.error('Error opening thread:', error);
            showToast('Failed to load thread', 'error');
        } finally {
            showLoading(false);
        }
    }

    // Show thread sidebar
    showThreadSidebar(threadData) {
        const sidebar = document.getElementById('rightSidebar');
        const threadContainer = document.getElementById('threadMessages');
        
        // Show sidebar
        sidebar.classList.add('open');
        
        // Render parent message
        const parentHtml = this.renderParentMessage(threadData.parent);
        
        // Render replies
        const repliesHtml = threadData.replies.map(reply => 
            this.renderReply(reply)
        ).join('');
        
        threadContainer.innerHTML = `
            <div class="thread-parent">
                ${parentHtml}
            </div>
            <div class="thread-divider">
                <span>${threadData.reply_count} ${threadData.reply_count === 1 ? 'reply' : 'replies'}</span>
            </div>
            <div class="thread-replies">
                ${repliesHtml}
            </div>
            <div class="thread-input">
                <input 
                    type="text" 
                    id="threadReplyInput" 
                    placeholder="Reply to thread..."
                    onkeypress="if(event.key==='Enter') threadManager.sendThreadReply()"
                >
                <button class="btn-primary" onclick="threadManager.sendThreadReply()">
                    <i class="fas fa-paper-plane"></i>
                </button>
            </div>
        `;
    }

    // Render parent message
    renderParentMessage(message) {
        const user = message.user;
        const initials = getUserInitials(user.full_name || user.username);
        
        return `
            <div class="thread-message parent">
                <div class="message-avatar" style="background: ${generateColorFromString(user.id)}">
                    ${initials}
                </div>
                <div class="message-content">
                    <div class="message-header">
                        <span class="message-author">${escapeHTML(user.full_name || user.username)}</span>
                        <span class="message-time">${formatTime(message.created_at)}</span>
                    </div>
                    <div class="message-text">${formatMessageText(message.text)}</div>
                </div>
            </div>
        `;
    }

    // Render reply
    renderReply(reply) {
        const user = reply.user;
        const initials = getUserInitials(user.full_name || user.username);
        
        return `
            <div class="thread-message reply" data-message-id="${reply.id}">
                <div class="message-avatar small" style="background: ${generateColorFromString(user.id)}">
                    ${initials}
                </div>
                <div class="message-content">
                    <div class="message-header">
                        <span class="message-author">${escapeHTML(user.full_name || user.username)}</span>
                        <span class="message-time">${formatTime(reply.created_at)}</span>
                    </div>
                    <div class="message-text">${formatMessageText(reply.text)}</div>
                </div>
            </div>
        `;
    }

    // Send thread reply
    async sendThreadReply() {
        const input = document.getElementById('threadReplyInput');
        const text = input.value.trim();
        
        if (!text || !this.currentThread) return;
        
        try {
            const response = await api.post(
                `/api/threads/${this.currentThread.parent.id}/reply/`,
                { text }
            );
            
            // Add reply to UI
            const repliesContainer = document.querySelector('.thread-replies');
            const replyHtml = this.renderReply(response.reply);
            repliesContainer.insertAdjacentHTML('beforeend', replyHtml);
            
            // Update reply count
            this.currentThread.reply_count++;
            const divider = document.querySelector('.thread-divider span');
            divider.textContent = `${this.currentThread.reply_count} ${this.currentThread.reply_count === 1 ? 'reply' : 'replies'}`;
            
            // Clear input
            input.value = '';
            
            // Scroll to bottom
            repliesContainer.scrollTop = repliesContainer.scrollHeight;
            
            // Update main message reply count badge
            this.updateMainMessageReplyCount(this.currentThread.parent.id);
            
        } catch (error) {
            console.error('Error sending reply:', error);
            showToast('Failed to send reply', 'error');
        }
    }

    // Close thread
    closeThread() {
        const sidebar = document.getElementById('rightSidebar');
        sidebar.classList.remove('open');
        
        this.currentThread = null;
        this.isThreadOpen = false;
    }

    // Update main message reply count
    updateMainMessageReplyCount(messageId) {
        const messageDiv = document.querySelector(`[data-message-id="${messageId}"]`);
        if (!messageDiv) return;
        
        const actionsDiv = messageDiv.querySelector('.message-actions');
        if (!actionsDiv) return;
        
        let replyBtn = actionsDiv.querySelector('.reply-count-badge');
        if (replyBtn) {
            const count = parseInt(replyBtn.dataset.count) + 1;
            replyBtn.dataset.count = count;
            replyBtn.innerHTML = `<i class="fas fa-reply"></i> ${count}`;
        }
    }

    // Add reply button to message
    static addReplyButton(messageId, replyCount = 0) {
        if (replyCount > 0) {
            return `
                <button class="btn-icon reply-count-badge" 
                        onclick="threadManager.openThread('${messageId}')"
                        data-count="${replyCount}"
                        title="View thread">
                    <i class="fas fa-reply"></i> ${replyCount}
                </button>
            `;
        }
        return '';
    }
}

// Create global instance
const threadManager = new ThreadManager();

// Update replyToMessage function
function replyToMessage(messageId) {
    threadManager.openThread(messageId);
}

function closeThread() {
    threadManager.closeThread();
}

console.log('✅ Thread manager loaded');
