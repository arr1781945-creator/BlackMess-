// Message Actions (Edit, Delete, etc.)

class MessageActions {
    constructor() {
        this.editingMessageId = null;
    }

    // Show message menu
    showMenu(messageId) {
        const messageDiv = document.querySelector(`[data-message-id="${messageId}"]`);
        if (!messageDiv) return;
        
        const message = this.getMessageData(messageDiv);
        const isOwner = message.userId === APP_STATE.user.id;
        
        const menuItems = [];
        
        // Edit (only owner, within 5 minutes)
        if (isOwner && this.canEdit(message.createdAt)) {
            menuItems.push(`
                <div class="menu-item" onclick="messageActions.startEdit('${messageId}')">
                    <i class="fas fa-edit"></i> Edit message
                </div>
            `);
        }
        
        // Delete (owner or admin)
        if (isOwner) {
            menuItems.push(`
                <div class="menu-item danger" onclick="messageActions.confirmDelete('${messageId}')">
                    <i class="fas fa-trash"></i> Delete message
                </div>
            `);
        }
        
        // Copy text
        menuItems.push(`
            <div class="menu-item" onclick="messageActions.copyText('${messageId}')">
                <i class="fas fa-copy"></i> Copy text
            </div>
        `);
        
        // Pin/Unpin
        menuItems.push(`
            <div class="menu-item" onclick="messageActions.togglePin('${messageId}')">
                <i class="fas fa-thumbtack"></i> ${message.isPinned ? 'Unpin' : 'Pin'} message
            </div>
        `);
        
        // Show menu modal
        showModal('Message Actions', `
            <div class="message-menu">
                ${menuItems.join('')}
            </div>
        `);
    }

    // Get message data from DOM
    getMessageData(messageDiv) {
        const timeStr = messageDiv.querySelector('.message-time')?.dataset.timestamp;
        const userId = messageDiv.querySelector('.message-avatar')?.dataset.userId;
        const isPinned = messageDiv.classList.contains('pinned');
        
        return {
            createdAt: timeStr ? new Date(timeStr) : null,
            userId: userId,
            isPinned: isPinned
        };
    }

    // Check if message can be edited
    canEdit(createdAt) {
        if (!createdAt) return false;
        const now = new Date();
        const diff = now - createdAt;
        const fiveMinutes = 5 * 60 * 1000;
        return diff < fiveMinutes;
    }

    // Start editing message
    startEdit(messageId) {
        closeModal();
        
        const messageDiv = document.querySelector(`[data-message-id="${messageId}"]`);
        if (!messageDiv) return;
        
        const textDiv = messageDiv.querySelector('.message-text');
        const currentText = textDiv.textContent.replace(' (edited)', '').trim();
        
        // Create edit input
        const editHtml = `
            <div class="message-edit-container">
                <textarea id="editMessageInput" class="edit-textarea">${escapeHTML(currentText)}</textarea>
                <div class="edit-actions">
                    <button class="btn btn-sm btn-primary" onclick="messageActions.saveEdit('${messageId}')">
                        <i class="fas fa-check"></i> Save
                    </button>
                    <button class="btn btn-sm" onclick="messageActions.cancelEdit('${messageId}')">
                        Cancel
                    </button>
                </div>
                <div class="edit-hint">
                    Press <kbd>Enter</kbd> to save, <kbd>Esc</kbd> to cancel
                </div>
            </div>
        `;
        
        textDiv.innerHTML = editHtml;
        
        const textarea = document.getElementById('editMessageInput');
        textarea.focus();
        textarea.setSelectionRange(textarea.value.length, textarea.value.length);
        
        // Handle keyboard shortcuts
        textarea.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.saveEdit(messageId);
            } else if (e.key === 'Escape') {
                e.preventDefault();
                this.cancelEdit(messageId);
            }
        });
        
        this.editingMessageId = messageId;
    }

    // Save edit
    async saveEdit(messageId) {
        const textarea = document.getElementById('editMessageInput');
        const newText = textarea?.value.trim();
        
        if (!newText) {
            showToast('Message cannot be empty', 'error');
            return;
        }
        
        try {
            const response = await api.put(`/api/messages/${messageId}/`, {
                text: newText
            });
            
            showToast('Message updated', 'success');
            
            // Update UI
            const messageDiv = document.querySelector(`[data-message-id="${messageId}"]`);
            const textDiv = messageDiv.querySelector('.message-text');
            textDiv.innerHTML = formatMessageText(newText) + ' <span class="edited">(edited)</span>';
            
            this.editingMessageId = null;
            
            // Broadcast via WebSocket
            if (wsManager.isConnected()) {
                wsManager.send({
                    type: 'message_edited',
                    message_id: messageId,
                    text: newText
                });
            }
            
        } catch (error) {
            console.error('Error editing message:', error);
            showToast(error.message || 'Failed to edit message', 'error');
        }
    }

    // Cancel edit
    cancelEdit(messageId) {
        // Reload message or restore original
        const messageDiv = document.querySelector(`[data-message-id="${messageId}"]`);
        if (!messageDiv) return;
        
        // Just reload the page section or restore from cache
        window.location.reload(); // Simple approach
    }

    // Confirm delete
    confirmDelete(messageId) {
        closeModal();
        
        showModal('Delete Message', `
            <div class="delete-confirm">
                <p>Are you sure you want to delete this message?</p>
                <p class="warning-text">This action cannot be undone.</p>
                <div class="delete-actions">
                    <button class="btn btn-danger btn-block" onclick="messageActions.deleteMessage('${messageId}')">
                        <i class="fas fa-trash"></i> Yes, Delete
                    </button>
                    <button class="btn btn-block" onclick="closeModal()">
                        Cancel
                    </button>
                </div>
            </div>
        `);
    }

    // Delete message
    async deleteMessage(messageId) {
        try {
            await api.delete(`/api/messages/${messageId}/`);
            
            showToast('Message deleted', 'success');
            closeModal();
            
            // Update UI
            const messageDiv = document.querySelector(`[data-message-id="${messageId}"]`);
            if (messageDiv) {
                messageDiv.classList.add('deleted');
                const textDiv = messageDiv.querySelector('.message-text');
                textDiv.innerHTML = '<em style="color: var(--text-tertiary);">[deleted]</em>';
                
                // Remove actions
                const actionsDiv = messageDiv.querySelector('.message-actions');
                if (actionsDiv) actionsDiv.remove();
            }
            
            // Broadcast via WebSocket
            if (wsManager.isConnected()) {
                wsManager.send({
                    type: 'message_deleted',
                    message_id: messageId
                });
            }
            
        } catch (error) {
            console.error('Error deleting message:', error);
            showToast('Failed to delete message', 'error');
        }
    }

    // Copy message text
    copyText(messageId) {
        const messageDiv = document.querySelector(`[data-message-id="${messageId}"]`);
        if (!messageDiv) return;
        
        const textDiv = messageDiv.querySelector('.message-text');
        const text = textDiv.textContent.replace(' (edited)', '').trim();
        
        navigator.clipboard.writeText(text).then(() => {
            showToast('Text copied to clipboard', 'success');
            closeModal();
        }).catch(err => {
            console.error('Copy failed:', err);
            showToast('Failed to copy text', 'error');
        });
    }

    // Toggle pin
    async togglePin(messageId) {
        try {
            await api.post(`/api/messages/${messageId}/pin/`);
            
            const messageDiv = document.querySelector(`[data-message-id="${messageId}"]`);
            const isPinned = messageDiv.classList.contains('pinned');
            
            if (isPinned) {
                messageDiv.classList.remove('pinned');
                showToast('Message unpinned', 'success');
            } else {
                messageDiv.classList.add('pinned');
                showToast('Message pinned', 'success');
            }
            
            closeModal();
            
        } catch (error) {
            console.error('Error toggling pin:', error);
            showToast('Failed to pin message', 'error');
        }
    }
}

// Create global instance
const messageActions = new MessageActions();

// Update showMessageMenu function
function showMessageMenu(messageId) {
    messageActions.showMenu(messageId);
}

console.log('✅ Message actions loaded');
