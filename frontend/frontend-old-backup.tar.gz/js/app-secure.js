/**
 * Main App with Security Integration
 */

// Initialize security on app load
async function initApp() {
    console.log('📱 Initializing SlackClone Ultra Secure...');
    
    // Show loading
    showLoading(true);
    
    try {
        // Check if user is authenticated
        if (auth.isAuthenticated()) {
            const user = auth.getCurrentUser();
            
            // Initialize security systems
            await window.secureSystem.initialize(
                user.username || user.email,
                'session_password' // In production, derive from session
            );
            
            // Load app
            await loadApp();
        } else {
            showLoginPage();
        }
    } catch (error) {
        console.error('Init error:', error);
        showToast('Failed to initialize security systems', 'error');
        showLoginPage();
    } finally {
        showLoading(false);
    }
}

// Override original sendMessage to add encryption
const originalSendMessage = window.sendMessage || function() {};

window.sendMessage = async function() {
    const input = document.getElementById('messageInput');
    const text = input.value.trim();
    
    if (!text || !APP_STATE.currentChannel) return;
    
    try {
        // Encrypt message
        const encrypted = await window.secureSystem.encryptMessage(text, {
            recipientPublicKey: 'channel_public_key', // Would get from channel
            recipientId: APP_STATE.currentChannel.id
        });
        
        // Send encrypted message
        if (encrypted.method !== 'NONE') {
            // Send via API with encryption metadata
            const message = await api.sendMessage(APP_STATE.currentChannel.id, JSON.stringify(encrypted));
            addMessageToUI(message);
        } else {
            // Fallback to original send
            originalSendMessage();
        }
        
        input.value = '';
        
    } catch (error) {
        console.error('Send error:', error);
        showToast('Failed to send encrypted message', 'error');
    }
};

// Security status modal
function toggleSecurityStatus() {
    const modal = document.getElementById('securityStatusModal');
    const content = document.getElementById('securityStatusContent');
    
    const status = window.secureSystem.getStatus();
    
    content.innerHTML = `
        <div class="security-status-grid">
            <div class="status-card ${status.e2ee ? 'active' : 'inactive'}">
                <i class="fas fa-lock"></i>
                <h4>End-to-End Encryption</h4>
                <p>${status.e2ee ? 'Active' : 'Inactive'}</p>
            </div>
            <div class="status-card ${status.pqc ? 'active' : 'inactive'}">
                <i class="fas fa-shield-alt"></i>
                <h4>Post-Quantum Crypto</h4>
                <p>${status.pqc ? 'Ready' : 'Not Ready'}</p>
            </div>
            <div class="status-card ${status.zkp ? 'active' : 'inactive'}">
                <i class="fas fa-user-secret"></i>
                <h4>Zero-Knowledge Auth</h4>
                <p>${status.zkp ? 'Active' : 'Inactive'}</p>
            </div>
            <div class="status-card ${status.antiScreenshot ? 'active' : 'inactive'}">
                <i class="fas fa-eye-slash"></i>
                <h4>Anti-Screenshot</h4>
                <p>${status.antiScreenshot ? 'Enabled' : 'Disabled'}</p>
            </div>
            <div class="status-card ${status.antiForensic ? 'active' : 'inactive'}">
                <i class="fas fa-eraser"></i>
                <h4>Anti-Forensic</h4>
                <p>${status.antiForensic ? 'Active' : 'Inactive'}</p>
            </div>
        </div>
        <div class="security-summary">
            <p><strong>User:</strong> ${status.user || 'Unknown'}</p>
            <p><strong>Status:</strong> ${status.ready ? '🟢 All Systems Operational' : '🔴 Not Ready'}</p>
        </div>
    `;
    
    modal.style.display = 'flex';
}

function closeSecurityStatus() {
    document.getElementById('securityStatusModal').style.display = 'none';
}

// Add event listener
document.getElementById('toggleSecurityStatus')?.addEventListener('click', toggleSecurityStatus);

// Initialize on load
document.addEventListener('DOMContentLoaded', initApp);

console.log('✅ Secure App loaded');
