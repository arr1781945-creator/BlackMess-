// Emoji Picker

class EmojiPicker {
    constructor() {
        this.emojis = {
            'Smileys & People': [
                '😀', '😃', '😄', '😁', '😆', '😅', '🤣', '😂', '🙂', '🙃',
                '😉', '😊', '😇', '🥰', '😍', '🤩', '😘', '😗', '😚', '😙',
                '😋', '😛', '😜', '🤪', '😝', '🤑', '🤗', '🤭', '🤫', '🤔',
                '🤐', '🤨', '😐', '😑', '😶', '😏', '😒', '🙄', '😬', '🤥',
                '😌', '😔', '😪', '🤤', '😴', '😷', '🤒', '🤕', '🤢', '🤮',
                '🤧', '🥵', '🥶', '😵', '🤯', '🤠', '🥳', '😎', '🤓', '🧐',
                '😕', '😟', '🙁', '😮', '😯', '😲', '😳', '🥺', '😦', '😧',
                '😨', '😰', '😥', '😢', '😭', '😱', '😖', '😣', '😞', '😓',
                '😩', '😫', '🥱', '😤', '😡', '😠', '🤬', '👍', '👎', '👏',
                '🙌', '👐', '🤝', '🙏', '✌️', '🤞', '🤟', '🤘', '🤙', '👋'
            ],
            'Animals & Nature': [
                '🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯',
                '🦁', '🐮', '🐷', '🐸', '🐵', '🐔', '🐧', '🐦', '🐤', '🦆',
                '🦅', '🦉', '🦇', '🐺', '🐗', '🐴', '🦄', '🐝', '🐛', '🦋',
                '🐌', '🐞', '🐜', '🦟', '🦗', '🕷️', '🦂', '🐢', '🐍', '🦎',
                '🐙', '🦑', '🦐', '🦀', '🐡', '🐠', '🐟', '🐬', '🐳', '🐋',
                '🦈', '🐊', '🐅', '🐆', '🦓', '🦍', '🦧', '🐘', '🦛', '🦏',
                '🌸', '🌺', '🌻', '🌷', '🌹', '🥀', '🌼', '🌵', '🌲', '🌳',
                '🌴', '🌱', '🌿', '🍀', '🍃', '🍂', '🍁', '🌾', '🌈', '⭐'
            ],
            'Food & Drink': [
                '🍎', '🍊', '🍋', '🍌', '🍉', '🍇', '🍓', '🍈', '🍒', '🍑',
                '🥭', '🍍', '🥥', '🥝', '🍅', '🍆', '🥑', '🥦', '🥬', '🥒',
                '🌶️', '🌽', '🥕', '🧄', '🧅', '🥔', '🍠', '🥐', '🥯', '🍞',
                '🥖', '🥨', '🧀', '🥚', '🍳', '🧈', '🥞', '🧇', '🥓', '🥩',
                '🍗', '🍖', '🦴', '🌭', '🍔', '🍟', '🍕', '🥪', '🥙', '🧆',
                '🌮', '🌯', '🥗', '🥘', '🍝', '🍜', '🍲', '🍛', '🍣', '🍱',
                '🥟', '🍤', '🍙', '🍚', '🍘', '🍥', '🥠', '🥮', '🍢', '🍡',
                '🍧', '🍨', '🍦', '🥧', '🧁', '🍰', '🎂', '🍮', '🍭', '🍬',
                '🍫', '🍿', '🍩', '🍪', '🌰', '🥜', '🍯', '🥛', '☕', '🍵',
                '🧃', '🥤', '🍶', '🍺', '🍻', '🥂', '🍷', '🥃', '🍸', '🍹'
            ],
            'Activity': [
                '⚽', '🏀', '🏈', '⚾', '🥎', '🎾', '🏐', '🏉', '🥏', '🎱',
                '🪀', '🏓', '🏸', '🏒', '🏑', '🥍', '🏏', '🥅', '⛳', '🪁',
                '🏹', '🎣', '🤿', '🥊', '🥋', '🎽', '🛹', '🛼', '🛷', '⛸️',
                '🥌', '🎿', '⛷️', '🏂', '🪂', '🏋️', '🤼', '🤸', '🤺', '⛹️',
                '🤾', '🏌️', '🏇', '🧘', '🏊', '🏄', '🚣', '🧗', '🚴', '🚵',
                '🎪', '🎭', '🎨', '🎬', '🎤', '🎧', '🎼', '🎹', '🥁', '🎷',
                '🎺', '🎸', '🪕', '🎻', '🎲', '♟️', '🎯', '🎳', '🎮', '🎰'
            ],
            'Travel & Places': [
                '🚗', '🚕', '🚙', '🚌', '🚎', '🏎️', '🚓', '🚑', '🚒', '🚐',
                '🚚', '🚛', '🚜', '🦯', '🦽', '🦼', '🛴', '🚲', '🛵', '🏍️',
                '🛺', '🚨', '🚔', '🚍', '🚘', '🚖', '🚡', '🚠', '🚟', '🚃',
                '🚋', '🚞', '🚝', '🚄', '🚅', '🚈', '🚂', '🚆', '🚇', '🚊',
                '🚉', '✈️', '🛫', '🛬', '🛩️', '💺', '🛰️', '🚀', '🛸', '🚁',
                '🛶', '⛵', '🚤', '🛥️', '🛳️', '⛴️', '🚢', '⚓', '⛽', '🚧',
                '🏠', '🏡', '🏘️', '🏚️', '🏗️', '🏭', '🏢', '🏬', '🏣', '🏤',
                '🏥', '🏦', '🏨', '🏪', '🏫', '🏩', '💒', '🏛️', '⛪', '🕌',
                '🕍', '🛕', '🕋', '⛩️', '🗾', '🎑', '🏞️', '🌅', '🌄', '🌠'
            ],
            'Objects': [
                '⌚', '📱', '💻', '⌨️', '🖥️', '🖨️', '🖱️', '🖲️', '🕹️', '🗜️',
                '💾', '💿', '📀', '📼', '📷', '📸', '📹', '🎥', '📽️', '🎞️',
                '📞', '☎️', '📟', '📠', '📺', '📻', '🎙️', '🎚️', '🎛️', '🧭',
                '⏱️', '⏲️', '⏰', '🕰️', '⌛', '⏳', '📡', '🔋', '🔌', '💡',
                '🔦', '🕯️', '🪔', '🧯', '🛢️', '💸', '💵', '💴', '💶', '💷',
                '💰', '💳', '💎', '⚖️', '🧰', '🔧', '🔨', '⚒️', '🛠️', '⛏️',
                '🔩', '⚙️', '🧱', '⛓️', '🧲', '🔫', '💣', '🧨', '🪓', '🔪',
                '🗡️', '⚔️', '🛡️', '🚬', '⚰️', '⚱️', '🏺', '🔮', '📿', '🧿',
                '💈', '⚗️', '🔭', '🔬', '🕳️', '💊', '💉', '🩸', '🩹', '🩺'
            ],
            'Symbols': [
                '❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔',
                '❣️', '💕', '💞', '💓', '💗', '💖', '💘', '💝', '💟', '☮️',
                '✝️', '☪️', '🕉️', '☸️', '✡️', '🔯', '🕎', '☯️', '☦️', '🛐',
                '⛎', '♈', '♉', '♊', '♋', '♌', '♍', '♎', '♏', '♐',
                '♑', '♒', '♓', '🆔', '⚛️', '🉑', '☢️', '☣️', '📴', '📳',
                '🈶', '🈚', '🈸', '🈺', '🈷️', '✴️', '🆚', '💮', '🉐', '㊙️',
                '㊗️', '🈴', '🈵', '🈹', '🈲', '🅰️', '🅱️', '🆎', '🆑', '🅾️',
                '🆘', '❌', '⭕', '🛑', '⛔', '📛', '🚫', '💯', '💢', '♨️',
                '🚷', '🚯', '🚳', '🚱', '🔞', '📵', '🚭', '❗', '❕', '❓'
            ]
        };
        
        this.currentCategory = 'Smileys & People';
        this.targetInput = null;
        this.isOpen = false;
    }

    // Show emoji picker
    show(inputElement) {
        this.targetInput = inputElement;
        
        if (this.isOpen) {
            this.close();
            return;
        }
        
        this.createPicker();
        this.isOpen = true;
    }

    // Create picker UI
    createPicker() {
        // Remove existing picker
        const existing = document.getElementById('emojiPicker');
        if (existing) existing.remove();
        
        const picker = document.createElement('div');
        picker.id = 'emojiPicker';
        picker.className = 'emoji-picker';
        
        // Categories
        const categoriesHtml = Object.keys(this.emojis).map(cat => `
            <button class="emoji-category ${cat === this.currentCategory ? 'active' : ''}" 
                    onclick="emojiPicker.selectCategory('${cat}')">
                ${this.getCategoryIcon(cat)}
            </button>
        `).join('');
        
        // Emojis
        const emojisHtml = this.emojis[this.currentCategory].map(emoji => `
            <button class="emoji-item" onclick="emojiPicker.selectEmoji('${emoji}')">
                ${emoji}
            </button>
        `).join('');
        
        picker.innerHTML = `
            <div class="emoji-categories">
                ${categoriesHtml}
            </div>
            <div class="emoji-search">
                <input type="text" placeholder="Search emoji..." 
                       oninput="emojiPicker.search(this.value)">
            </div>
            <div class="emoji-grid" id="emojiGrid">
                ${emojisHtml}
            </div>
        `;
        
        document.body.appendChild(picker);
        
        // Position picker
        this.positionPicker();
        
        // Close on outside click
        setTimeout(() => {
            document.addEventListener('click', this.handleOutsideClick.bind(this));
        }, 100);
    }

    // Get category icon
    getCategoryIcon(category) {
        const icons = {
            'Smileys & People': '😀',
            'Animals & Nature': '🐶',
            'Food & Drink': '🍔',
            'Activity': '⚽',
            'Travel & Places': '✈️',
            'Objects': '💡',
            'Symbols': '❤️'
        };
        return icons[category] || '😀';
    }

    // Select category
    selectCategory(category) {
        this.currentCategory = category;
        
        // Update active category
        document.querySelectorAll('.emoji-category').forEach(btn => {
            btn.classList.remove('active');
        });
        event.target.classList.add('active');
        
        // Update emoji grid
        const grid = document.getElementById('emojiGrid');
        grid.innerHTML = this.emojis[category].map(emoji => `
            <button class="emoji-item" onclick="emojiPicker.selectEmoji('${emoji}')">
                ${emoji}
            </button>
        `).join('');
    }

    // Search emojis
    search(query) {
        if (!query.trim()) {
            this.selectCategory(this.currentCategory);
            return;
        }
        
        const grid = document.getElementById('emojiGrid');
        const allEmojis = Object.values(this.emojis).flat();
        
        // For now, just show all emojis
        // In production, you'd want to search by emoji name/keywords
        grid.innerHTML = allEmojis.map(emoji => `
            <button class="emoji-item" onclick="emojiPicker.selectEmoji('${emoji}')">
                ${emoji}
            </button>
        `).join('');
    }

    // Select emoji
    selectEmoji(emoji) {
        if (!this.targetInput) return;
        
        const start = this.targetInput.selectionStart;
        const end = this.targetInput.selectionEnd;
        const text = this.targetInput.value;
        
        // Insert emoji at cursor position
        this.targetInput.value = text.substring(0, start) + emoji + text.substring(end);
        
        // Set cursor after emoji
        const newPos = start + emoji.length;
        this.targetInput.setSelectionRange(newPos, newPos);
        
        this.targetInput.focus();
        
        // Trigger input event
        this.targetInput.dispatchEvent(new Event('input', { bubbles: true }));
        
        // Don't close picker, allow multiple selections
        // this.close();
    }

    // Position picker
    positionPicker() {
        const picker = document.getElementById('emojiPicker');
        if (!picker || !this.targetInput) return;
        
        const rect = this.targetInput.getBoundingClientRect();
        
        picker.style.position = 'fixed';
        picker.style.bottom = (window.innerHeight - rect.top + 5) + 'px';
        picker.style.left = rect.left + 'px';
        picker.style.width = '350px';
    }

    // Handle outside click
    handleOutsideClick(e) {
        const picker = document.getElementById('emojiPicker');
        if (picker && !picker.contains(e.target) && e.target !== this.targetInput) {
            this.close();
        }
    }

    // Close picker
    close() {
        const picker = document.getElementById('emojiPicker');
        if (picker) picker.remove();
        
        this.isOpen = false;
        this.targetInput = null;
        
        document.removeEventListener('click', this.handleOutsideClick.bind(this));
    }
}

// Create global instance
const emojiPicker = new EmojiPicker();

// Update showEmoji function
function showEmoji() {
    const input = document.getElementById('messageInput');
    emojiPicker.show(input);
}

console.log('✅ Emoji picker loaded');

// Quick reaction picker
class QuickReactionPicker {
    constructor() {
        this.quickEmojis = ['👍', '❤️', '😂', '😮', '😢', '👏', '🎉', '🔥'];
    }

    // Show quick reactions
    show(messageId, buttonElement) {
        // Remove existing
        const existing = document.getElementById('quickReactions');
        if (existing) existing.remove();
        
        const picker = document.createElement('div');
        picker.id = 'quickReactions';
        picker.className = 'quick-reactions';
        
        picker.innerHTML = this.quickEmojis.map(emoji => `
            <button class="quick-emoji" onclick="quickReactions.select('${messageId}', '${emoji}')">
                ${emoji}
            </button>
        `).join('');
        
        // Position near button
        const rect = buttonElement.getBoundingClientRect();
        picker.style.position = 'fixed';
        picker.style.top = (rect.top - 50) + 'px';
        picker.style.left = rect.left + 'px';
        
        document.body.appendChild(picker);
        
        // Close on outside click
        setTimeout(() => {
            document.addEventListener('click', (e) => {
                if (!picker.contains(e.target) && e.target !== buttonElement) {
                    picker.remove();
                }
            }, { once: true });
        }, 100);
    }

    // Select emoji
    select(messageId, emoji) {
        // Send reaction via WebSocket
        if (wsManager.isConnected()) {
            wsManager.sendReaction(messageId, emoji);
        }
        
        // Close picker
        const picker = document.getElementById('quickReactions');
        if (picker) picker.remove();
    }
}

// Create global instance
const quickReactions = new QuickReactionPicker();

// Update addReaction function
function addReaction(messageId) {
    const button = event.target.closest('.btn-icon');
    quickReactions.show(messageId, button);
}
