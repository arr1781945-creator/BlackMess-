// File Upload Handler

class FileUploadManager {
    constructor() {
        this.maxFileSize = 10 * 1024 * 1024; // 10MB
        this.allowedTypes = [
            'image/jpeg', 'image/png', 'image/gif', 'image/webp',
            'application/pdf', 'text/plain',
            'application/msword', 
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/zip'
        ];
    }

    // Show file upload dialog
    showFileUpload() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = this.allowedTypes.join(',');
        
        input.onchange = (e) => {
            const file = e.target.files[0];
            if (file) {
                this.handleFileSelect(file);
            }
        };
        
        input.click();
    }

    // Handle file selection
    handleFileSelect(file) {
        // Validate file size
        if (file.size > this.maxFileSize) {
            showToast('File too large. Maximum size is 10MB', 'error');
            return;
        }

        // Validate file type
        if (!this.allowedTypes.includes(file.type)) {
            showToast('File type not allowed', 'error');
            return;
        }

        // Show upload preview
        this.showUploadPreview(file);
    }

    // Show upload preview
    showUploadPreview(file) {
        const preview = this.createPreview(file);
        
        showModal('Upload File', `
            <div class="file-upload-preview">
                ${preview}
                <div class="form-group">
                    <label>Add a message (optional)</label>
                    <input type="text" id="fileMessage" placeholder="Say something about this file...">
                </div>
                <div class="upload-actions">
                    <button class="btn btn-primary" onclick="fileUploadManager.uploadFile()">
                        <i class="fas fa-upload"></i> Upload
                    </button>
                    <button class="btn" onclick="closeModal()">
                        Cancel
                    </button>
                </div>
            </div>
        `);

        // Store file temporarily
        this.currentFile = file;
    }

    // Create file preview
    createPreview(file) {
        if (file.type.startsWith('image/')) {
            const url = URL.createObjectURL(file);
            return `
                <div class="image-preview">
                    <img src="${url}" alt="${file.name}" style="max-width: 100%; max-height: 300px;">
                </div>
            `;
        } else {
            const icon = this.getFileIcon(file.type);
            return `
                <div class="file-preview">
                    <i class="fas ${icon} fa-4x"></i>
                    <p><strong>${file.name}</strong></p>
                    <p>${this.formatFileSize(file.size)}</p>
                </div>
            `;
        }
    }

    // Upload file
    async uploadFile() {
        if (!this.currentFile) return;
        if (!APP_STATE.currentChannel) {
            showToast('No channel selected', 'error');
            return;
        }

        const message = document.getElementById('fileMessage')?.value || '';
        
        showLoading(true);
        closeModal();

        try {
            const formData = new FormData();
            formData.append('file', this.currentFile);
            formData.append('channel_id', APP_STATE.currentChannel.id);
            formData.append('message', message);

            const response = await fetch(
                API_CONFIG.BASE_URL + '/api/files/upload/',
                {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${api.getToken()}`
                    },
                    body: formData
                }
            );

            if (!response.ok) {
                throw new Error('Upload failed');
            }

            const data = await response.json();
            
            showToast('File uploaded successfully!', 'success');
            
            // Clear current file
            this.currentFile = null;

        } catch (error) {
            console.error('Upload error:', error);
            showToast('Failed to upload file', 'error');
        } finally {
            showLoading(false);
        }
    }

    // Get file icon
    getFileIcon(mimeType) {
        if (mimeType.startsWith('image/')) return 'fa-file-image';
        if (mimeType.startsWith('video/')) return 'fa-file-video';
        if (mimeType.startsWith('audio/')) return 'fa-file-audio';
        if (mimeType.includes('pdf')) return 'fa-file-pdf';
        if (mimeType.includes('word')) return 'fa-file-word';
        if (mimeType.includes('excel') || mimeType.includes('spreadsheet')) return 'fa-file-excel';
        if (mimeType.includes('zip') || mimeType.includes('rar')) return 'fa-file-archive';
        return 'fa-file';
    }

    // Format file size
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    }
}

// Create global instance
const fileUploadManager = new FileUploadManager();

// Update showFileUpload function
function showFileUpload() {
    fileUploadManager.showFileUpload();
}

console.log('✅ File upload module loaded');
