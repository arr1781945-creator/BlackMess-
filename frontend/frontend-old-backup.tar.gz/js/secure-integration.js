/**
 * Secure Integration for SlackClone
 * Integrates all security features into existing app
 */

class SlackCloneSecure {
    constructor() {
        this.e2ee = new SecureE2EE();
        this.pqc = new SecurePQC();
        this.zkp = new ZeroKnowledgeAuth();
        this.selfDestruct = new SelfDestruct();
        this.antiScreenshot = new AntiScreenshot();
        this.antiForensic = new AntiForensic();
        
        this.ready = false;
        this.currentUser = null;
    }

    async initialize(username, password) {
        try {
            console.log('🔒 Initializing security systems...');

            // Initialize all modules
            await this.e2ee.initialize();
            await this.pqc.initialize();
            await this.zkp.initialize();
            
            // Enable protections
            this.antiScreenshot.enable();
            this.antiForensic.initialize();
            
            // Setup session timeout (30 min)
            this.antiForensic.setupSessionTimeout(30, () => {
                this.onSessionTimeout();
            });

            // Store user
            this.currentUser = username;
            
            this.ready = true;

            console.log('✅ All security systems ready!');

            return {
                success: true,
                publicKeys: {
                    e2ee: this.e2ee.exportPublicKey(),
                    pqc: this.pqc.exportPublicKey()
                }
            };
        } catch (error) {
            console.error('Security init failed:', error);
            throw error;
        }
    }

    /**
     * Encrypt message before sending
     */
    async encryptMessage(message, options = {}) {
        try {
            const useE2EE = document.getElementById('enableE2EE')?.checked !== false;
            const usePQC = document.getElementById('enablePQC')?.checked === true;
            const useSelfDestruct = document.getElementById('selfDestruct')?.checked === true;

            let encrypted;

            if (usePQC && options.recipientPQCKey) {
                // Use Post-Quantum encryption
                encrypted = this.pqc.encrypt(message, options.recipientPQCKey);
                encrypted.method = 'PQC';
            } else if (useE2EE && options.recipientPublicKey) {
                // Use E2EE
                encrypted = this.e2ee.encrypt(
                    message,
                    options.recipientPublicKey,
                    options.recipientId || 'unknown'
                );
                encrypted.method = 'E2EE';
            } else {
                // No encryption (fallback)
                return {
                    plaintext: message,
                    method: 'NONE'
                };
            }

            // Add self-destruct if enabled
            if (useSelfDestruct) {
                const msgId = `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
                
                this.selfDestruct.create(msgId, {
                    timeout: 60000, // 1 minute
                    readOnce: true,
                    burnAfterReading: true
                });

                encrypted.messageId = msgId;
                encrypted.selfDestruct = true;
            }

            return encrypted;

        } catch (error) {
            console.error('Encryption failed:', error);
            throw error;
        }
    }

    /**
     * Decrypt received message
     */
    async decryptMessage(encryptedData, options = {}) {
        try {
            if (!encryptedData.method) {
                // Not encrypted
                return encryptedData.plaintext || encryptedData;
            }

            let decrypted;

            if (encryptedData.method === 'PQC') {
                decrypted = this.pqc.decrypt(encryptedData, options.senderPQCKey);
            } else if (encryptedData.method === 'E2EE') {
                decrypted = this.e2ee.decrypt(encryptedData, options.senderPublicKey);
            }

            // Handle self-destruct
            if (encryptedData.selfDestruct && encryptedData.messageId) {
                this.selfDestruct.markAsRead(encryptedData.messageId);
            }

            return decrypted;

        } catch (error) {
            console.error('Decryption failed:', error);
            return '[🔒 Encrypted message - cannot decrypt]';
        }
    }

    /**
     * Get security status
     */
    getStatus() {
        return {
            ready: this.ready,
            user: this.currentUser,
            e2ee: this.e2ee.keyPair !== null,
            pqc: this.pqc.ready,
            zkp: this.zkp.ready,
            antiScreenshot: this.antiScreenshot.isActive,
            antiForensic: true
        };
    }

    /**
     * Session timeout handler
     */
    onSessionTimeout() {
        console.warn('⏰ Session timeout - logging out');
        
        // Emergency cleanup
        this.antiForensic.completeCleanup();
        this.e2ee.destroy();
        this.pqc.destroy();
        this.zkp.destroy();
        
        // Logout
        window.location.href = '/';
    }

    /**
     * Protect message elements from screenshots
     */
    protectMessage(element) {
        this.antiScreenshot.protect(element);
    }
}

// Global instance
window.secureSystem = new SlackCloneSecure();

console.log('✅ Secure Integration loaded');
