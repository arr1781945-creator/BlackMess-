// Theme Manager

class ThemeManager {
    constructor() {
        this.currentTheme = 'light';
        this.storageKey = 'app_theme';
        this.init();
    }

    // Initialize theme
    init() {
        // Load saved theme or detect system preference
        const savedTheme = localStorage.getItem(this.storageKey);
        
        if (savedTheme) {
            this.currentTheme = savedTheme;
        } else {
            // Check system preference
            if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                this.currentTheme = 'dark';
            }
        }
        
        this.applyTheme(this.currentTheme);
        
        // Listen for system theme changes
        if (window.matchMedia) {
            window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
                if (!localStorage.getItem(this.storageKey)) {
                    this.setTheme(e.matches ? 'dark' : 'light');
                }
            });
        }
    }

    // Apply theme
    applyTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        this.currentTheme = theme;
        this.updateToggleButton();
    }

    // Set theme
    setTheme(theme) {
        this.applyTheme(theme);
        localStorage.setItem(this.storageKey, theme);
        
        // Show toast
        const emoji = theme === 'dark' ? '🌙' : '☀️';
        showToast(`${emoji} ${theme === 'dark' ? 'Dark' : 'Light'} mode enabled`, 'info');
    }

    // Toggle theme
    toggle() {
        const newTheme = this.currentTheme === 'light' ? 'dark' : 'light';
        this.setTheme(newTheme);
    }

    // Update toggle button
    updateToggleButton() {
        const button = document.getElementById('themeToggle');
        if (!button) return;
        
        const icon = button.querySelector('i');
        if (icon) {
            if (this.currentTheme === 'dark') {
                icon.className = 'fas fa-sun';
                button.title = 'Switch to light mode';
            } else {
                icon.className = 'fas fa-moon';
                button.title = 'Switch to dark mode';
            }
        }
    }

    // Get current theme
    getTheme() {
        return this.currentTheme;
    }

    // Show theme selector
    showSelector() {
        showModal('Choose Theme', `
            <div class="theme-selector">
                <button class="theme-option ${this.currentTheme === 'light' ? 'active' : ''}" 
                        onclick="themeManager.setTheme('light'); closeModal();">
                    <i class="fas fa-sun fa-3x"></i>
                    <h4>Light Mode</h4>
                    <p>Classic bright appearance</p>
                </button>
                
                <button class="theme-option ${this.currentTheme === 'dark' ? 'active' : ''}" 
                        onclick="themeManager.setTheme('dark'); closeModal();">
                    <i class="fas fa-moon fa-3x"></i>
                    <h4>Dark Mode</h4>
                    <p>Easy on the eyes</p>
                </button>
                
                <button class="theme-option ${this.currentTheme === 'auto' ? 'active' : ''}" 
                        onclick="themeManager.setTheme('auto'); closeModal();">
                    <i class="fas fa-adjust fa-3x"></i>
                    <h4>Auto</h4>
                    <p>Follow system preference</p>
                </button>
            </div>
        `);
    }
}

// Create global instance
const themeManager = new ThemeManager();

console.log('✅ Theme manager loaded');

// Sync theme with backend user preferences
ThemeManager.prototype.syncWithBackend = async function() {
    if (!APP_STATE.user) return;
    
    try {
        // Get user preferences
        const prefs = await api.get('/api/preferences/');
        
        if (prefs.theme && prefs.theme !== this.currentTheme) {
            this.setTheme(prefs.theme);
        }
    } catch (error) {
        console.error('Failed to sync theme:', error);
    }
};

// Save theme to backend
ThemeManager.prototype.saveToBackend = async function(theme) {
    if (!APP_STATE.user) return;
    
    try {
        await api.put('/api/preferences/', {
            theme: theme
        });
    } catch (error) {
        console.error('Failed to save theme:', error);
    }
};

// Update setTheme to save to backend
const _originalSetTheme = ThemeManager.prototype.setTheme;
ThemeManager.prototype.setTheme = function(theme) {
    _originalSetTheme.call(this, theme);
    this.saveToBackend(theme);
};

// Sync on app load
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        if (APP_STATE.user) {
            themeManager.syncWithBackend();
        }
    }, 1000);
});

// Update applyTheme with animation
const _originalApplyTheme = ThemeManager.prototype.applyTheme;
ThemeManager.prototype.applyTheme = function(theme) {
    // Add animation class
    document.body.classList.add('theme-changing');
    
    // Apply theme
    _originalApplyTheme.call(this, theme);
    
    // Remove animation class
    setTimeout(() => {
        document.body.classList.remove('theme-changing');
    }, 300);
};
