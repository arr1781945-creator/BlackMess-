const Templates = {
    splash: () => `
        <div style="text-align: center; color: white;">
            <svg viewBox="0 0 124 124" fill="none" style="width: 100px; height: 100px; margin-bottom: 20px;">
                <path d="M26.4 78.3L45.7 71.8L52.2 91.1L32.9 97.6C28.5 99.1 23.7 96.8 22.2 92.4C20.7 88 23 83.2 27.4 81.7L26.4 78.3Z" fill="#E01E5A"/>
                <path d="M45.7 52.2L26.4 45.7C22 44.2 19.7 39.4 21.2 35C22.7 30.6 27.5 28.3 31.9 29.8L51.2 36.3L45.7 52.2Z" fill="#36C5F0"/>
                <path d="M71.8 45.7L78.3 26.4C79.8 22 84.6 19.7 89 21.2C93.4 22.7 95.7 27.5 94.2 31.9L87.7 51.2L71.8 45.7Z" fill="#2EB67D"/>
                <path d="M97.6 71.8L78.3 78.3L71.8 59L91.1 52.5C95.5 51 100.3 53.3 101.8 57.7C103.3 62.1 101 66.9 96.6 68.4L97.6 71.8Z" fill="#ECB22E"/>
            </svg>
            <h1 style="font-size: 48px; font-weight: 700;">SlackClone</h1>
            <p style="font-size: 16px; opacity: 0.8; margin-top: 8px;">Where work happens</p>
        </div>
    `,

    login: () => `
        <div class="auth-container">
            <div class="auth-box">
                <div style="text-align: center; margin-bottom: 32px;">
                    <h1 style="font-size: 36px; color: #4A154B; margin-bottom: 8px;">SlackClone</h1>
                    <p style="color: #616061;">Sign in to your workspace</p>
                </div>
                <form id="loginForm">
                    <div class="form-group">
                        <label>Email address</label>
                        <input type="email" id="loginEmail" required placeholder="name@work-email.com">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" id="loginPassword" required placeholder="Your password">
                    </div>
                    <button type="submit" class="btn btn-primary">Sign In</button>
                    <div style="text-align: center; margin-top: 24px; color: #616061;">
                        Don't have an account? <a href="#" onclick="showSignup()" style="color: #1264A3; text-decoration: none;">Create one</a>
                    </div>
                </form>
            </div>
        </div>
    `,

    signup: () => `
        <div class="auth-container">
            <div class="auth-box">
                <div style="text-align: center; margin-bottom: 32px;">
                    <h1 style="font-size: 36px; color: #4A154B;">Create account</h1>
                </div>
                <form id="signupForm">
                    <div class="form-group">
                        <label>Full name</label>
                        <input type="text" id="signupName" required placeholder="Your name">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" id="signupEmail" required placeholder="name@work-email.com">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" id="signupPassword" required placeholder="Password" minlength="6">
                    </div>
                    <button type="submit" class="btn btn-primary">Create Account</button>
                    <div style="text-align: center; margin-top: 20px;">
                        <a href="#" onclick="showLogin()" style="color: #1264A3; text-decoration: none;">Back to login</a>
                    </div>
                </form>
            </div>
        </div>
    `,

    workspaceSetup: () => `
        <div style="min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 40px;">
            <div style="max-width: 600px; width: 100%; text-align: center;">
                <h2 style="font-size: 36px; margin-bottom: 16px;">What's your workspace name?</h2>
                <p style="color: #616061; margin-bottom: 40px;">This will be the name of your team</p>
                <form id="workspaceForm">
                    <div class="form-group">
                        <input type="text" id="workspaceName" required placeholder="My Company" style="text-align: center; font-size: 20px; padding: 20px;">
                    </div>
                    <button type="submit" class="btn btn-primary">Continue</button>
                </form>
            </div>
        </div>
    `,

    mainApp: (workspaceName, userName) => `
        <div style="width: 68px; background: #4A154B; display: flex; flex-direction: column; align-items: center; padding: 8px 0; gap: 8px;">
            <div style="width: 44px; height: 44px; border-radius: 8px; background: white; color: #4A154B; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 18px;">
                ${workspaceName.charAt(0).toUpperCase()}
            </div>
        </div>
        <div class="sidebar">
            <div style="padding: 16px; border-bottom: 1px solid rgba(255,255,255,0.1);">
                <div style="color: white; font-size: 18px; font-weight: 900;">${workspaceName}</div>
            </div>
            <div style="padding: 16px;">
                <div style="color: rgba(255,255,255,0.7); font-size: 13px; margin-bottom: 8px;">Channels</div>
                <div style="padding: 6px 16px; background: #1164A3; border-radius: 4px; color: white; cursor: pointer;">
                    <i class="fas fa-hashtag"></i> general
                </div>
            </div>
            <div style="margin-top: auto; padding: 16px; border-top: 1px solid rgba(255,255,255,0.1);">
                <div style="color: white; font-weight: 600;">${userName}</div>
                <div style="font-size: 12px; color: rgba(255,255,255,0.6);">
                    <i class="fas fa-circle" style="font-size: 8px; color: #2BAC76;"></i> Active
                </div>
            </div>
        </div>
        <div class="main-view">
            <div style="padding: 16px 20px; border-bottom: 1px solid #E0E0E0;">
                <h1 style="font-size: 20px; font-weight: 700;">
                    <i class="fas fa-hashtag" style="color: #616061;"></i> general
                </h1>
            </div>
            <div class="messages-view" id="messagesView">
                <div style="text-align: center; padding: 40px; color: #616061;">
                    <div style="font-size: 48px; margin-bottom: 16px;"><i class="fas fa-hashtag"></i></div>
                    <h3 style="color: #1D1C1D; margin-bottom: 8px;">Welcome to #general</h3>
                    <p>This is the start of your workspace</p>
                </div>
            </div>
            <div class="message-input-box">
                <textarea id="messageInput" placeholder="Message #general" rows="3"></textarea>
                <div style="padding: 8px; text-align: right;">
                    <button onclick="sendMessage()" style="padding: 8px 20px; background: #007a5a; color: white; border: none; border-radius: 4px; cursor: pointer;">
                        <i class="fas fa-paper-plane"></i> Send
                    </button>
                </div>
            </div>
        </div>
    `
};
