// WebSocket Manager
class WebSocketManager {
    constructor() {
        this.socket = null;
        this.channelId = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectDelay = 3000;
        this.typingTimeout = null;
    }

    // Connect to WebSocket
    connect(channelId) {
        if (this.socket && this.socket.readyState === WebSocket.OPEN) {
            this.disconnect();
        }

        this.channelId = channelId;
        const wsUrl = `${API_CONFIG.WS_URL}/ws/chat/${channelId}/`;

        console.log('🔌 Connecting to WebSocket:', wsUrl);

        try {
            this.socket = new WebSocket(wsUrl);
            this.setupEventHandlers();
        } catch (error) {
            console.error('❌ WebSocket connection error:', error);
            showToast('Failed to connect to chat', 'error');
        }
    }

    // Setup event handlers
    setupEventHandlers() {
        this.socket.onopen = (event) => {
            console.log('✅ WebSocket connected');
            this.reconnectAttempts = 0;
            APP_STATE.isConnected = true;
            updateConnectionStatus(true);
            showToast('Connected to chat', 'success');
        };

        this.socket.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                console.log('📨 WebSocket message:', data);
                this.handleMessage(data);
            } catch (error) {
                console.error('Error parsing WebSocket message:', error);
            }
        };

        this.socket.onerror = (error) => {
            console.error('❌ WebSocket error:', error);
            showToast('Connection error', 'error');
        };

        this.socket.onclose = (event) => {
            console.log('🔌 WebSocket disconnected');
            APP_STATE.isConnected = false;
            updateConnectionStatus(false);
            
            // Attempt reconnect
            if (this.reconnectAttempts < this.maxReconnectAttempts) {
                this.reconnectAttempts++;
                console.log(`🔄 Reconnecting... Attempt ${this.reconnectAttempts}`);
                setTimeout(() => {
                    if (this.channelId) {
                        this.connect(this.channelId);
                    }
                }, this.reconnectDelay);
            } else {
                showToast('Disconnected from chat', 'error');
            }
        };
    }

    // Handle incoming messages
    handleMessage(data) {
        switch (data.type) {
            case 'message':
                this.handleChatMessage(data.message);
                break;
                
            case 'typing':
                this.handleTypingIndicator(data);
                break;
                
            case 'user_joined':
                this.handleUserJoined(data);
                break;
                
            case 'user_left':
                this.handleUserLeft(data);
                break;
                
            case 'reaction':
                this.handleReaction(data);
                break;
                
            case 'message_deleted':
                this.handleMessageDeleted(data);
                break;
                
            case 'message_edited':
                this.handleMessageEdited(data);
                break;
                
            default:
                console.log('Unknown message type:', data.type);
        }
    }

    // Handle chat message
    handleChatMessage(message) {
        addMessageToUI(message);
        
        // Play notification sound (optional)
        // this.playNotificationSound();
    }

    // Handle typing indicator
    handleTypingIndicator(data) {
        const typingDiv = document.getElementById('typingIndicator');
        
        if (data.is_typing) {
            typingDiv.textContent = `${data.username} is typing...`;
        } else {
            typingDiv.textContent = '';
        }
    }

    // Handle user joined
    handleUserJoined(data) {
        showToast(`${data.username} joined`, 'info');
    }

    // Handle user left
    handleUserLeft(data) {
        showToast(`${data.username} left`, 'info');
    }

    // Handle reaction
    handleReaction(data) {
        updateMessageReaction(data.message_id, data.emoji, data.user_id, data.action);
    }

    // Handle message deleted
    handleMessageDeleted(data) {
        removeMessageFromUI(data.message_id);
    }

    // Handle message edited
    handleMessageEdited(data) {
        updateMessageInUI(data.message);
    }

    // Send message
    sendMessage(text) {
        if (!this.isConnected()) {
            showToast('Not connected to chat', 'error');
            return false;
        }

        this.send({
            type: 'message',
            text: text
        });

        return true;
    }

    // Send typing indicator
    sendTyping(isTyping) {
        if (!this.isConnected()) return;

        this.send({
            type: 'typing',
            is_typing: isTyping
        });
    }

    // Send reaction
    sendReaction(messageId, emoji) {
        if (!this.isConnected()) return;

        this.send({
            type: 'reaction',
            message_id: messageId,
            emoji: emoji
        });
    }

    // Generic send method
    send(data) {
        if (this.socket && this.socket.readyState === WebSocket.OPEN) {
            this.socket.send(JSON.stringify(data));
        }
    }

    // Check if connected
    isConnected() {
        return this.socket && this.socket.readyState === WebSocket.OPEN;
    }

    // Disconnect
    disconnect() {
        if (this.socket) {
            this.socket.close();
            this.socket = null;
            this.channelId = null;
        }
    }
}

// Create global WebSocket instance
const wsManager = new WebSocketManager();

console.log('✅ WebSocket manager loaded');

// Update handleChatMessage to support threads
const originalHandleChatMessage = WebSocketManager.prototype.handleChatMessage;
WebSocketManager.prototype.handleChatMessage = function(message) {
    // If it's a thread reply and thread is open, add to thread
    if (message.parent_message && threadManager.isThreadOpen) {
        if (threadManager.currentThread?.parent.id === message.parent_message) {
            const repliesContainer = document.querySelector('.thread-replies');
            if (repliesContainer) {
                const replyHtml = threadManager.renderReply(message);
                repliesContainer.insertAdjacentHTML('beforeend', replyHtml);
                repliesContainer.scrollTop = repliesContainer.scrollHeight;
            }
        }
    }
    
    // Add to main chat
    addMessageToUI(message);
};

// Handle message edited via WebSocket
WebSocketManager.prototype.handleMessageEdited = function(data) {
    const messageDiv = document.querySelector(`[data-message-id="${data.message_id}"]`);
    if (!messageDiv) return;
    
    const textDiv = messageDiv.querySelector('.message-text');
    if (textDiv) {
        textDiv.innerHTML = formatMessageText(data.text) + ' <span class="edited">(edited)</span>';
    }
};

// Handle message deleted via WebSocket
WebSocketManager.prototype.handleMessageDeleted = function(data) {
    const messageDiv = document.querySelector(`[data-message-id="${data.message_id}"]`);
    if (!messageDiv) return;
    
    messageDiv.classList.add('deleted');
    const textDiv = messageDiv.querySelector('.message-text');
    if (textDiv) {
        textDiv.innerHTML = '<em style="color: var(--text-tertiary);">[deleted]</em>';
    }
    
    // Remove actions
    const actionsDiv = messageDiv.querySelector('.message-actions');
    if (actionsDiv) actionsDiv.remove();
};

// Update setupEventHandlers to handle online users
const _origSetupEventHandlers = WebSocketManager.prototype.setupEventHandlers;
WebSocketManager.prototype.setupEventHandlers = function() {
    _origSetupEventHandlers.call(this);
    
    const originalOnMessage = this.socket.onmessage;
    this.socket.onmessage = (event) => {
        try {
            const data = JSON.parse(event.data);
            
            // Handle online users list
            if (data.type === 'online_users') {
                onlineUsers.setUsers(data.users);
                return;
            }
            
            // Handle presence update
            if (data.type === 'presence_update') {
                onlineUsers.updateUserStatus(
                    data.user_id, 
                    data.status, 
                    data.status_text
                );
                return;
            }
            
            // Call original handler
            originalOnMessage.call(this, event);
        } catch (error) {
            console.error('Error parsing WebSocket message:', error);
        }
    };
};

// Update handleUserJoined
WebSocketManager.prototype.handleUserJoined = function(data) {
    showToast(`${data.username} joined`, 'info');
    
    // Add to online users
    onlineUsers.addUser({
        id: data.user_id,
        username: data.username,
        full_name: data.full_name || data.username,
        status: 'active',
        status_text: ''
    });
};

// Update handleUserLeft
WebSocketManager.prototype.handleUserLeft = function(data) {
    showToast(`${data.username} left`, 'info');
    
    // Remove from online users
    onlineUsers.removeUser(data.user_id);
};

// Send presence update
WebSocketManager.prototype.updatePresence = function(status, statusText = '') {
    if (!this.isConnected()) return;
    
    this.send({
        type: 'presence_update',
        status: status,
        status_text: statusText
    });
};
