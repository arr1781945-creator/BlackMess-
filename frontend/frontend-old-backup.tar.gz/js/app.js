// Main Application Logic

// Initialize app
async function initApp() {
    console.log('🚀 Initializing app...');
    
    // Check if user is authenticated
    if (auth.isAuthenticated()) {
        await loadApp();
    } else {
        showLoginPage();
    }
}

// Show login page
function showLoginPage() {
    showLoading(false);
    document.getElementById('loginPage').classList.add('active');
    document.getElementById('registerPage').classList.remove('active');
    document.getElementById('appPage').classList.remove('active');
}

// Load main app
async function loadApp() {
    showLoading(true);
    
    try {
        // Get user data
        APP_STATE.user = auth.getCurrentUser();
        
        if (!APP_STATE.user) {
            // Fetch fresh user data
            APP_STATE.user = await api.getProfile();
            localStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(APP_STATE.user));
        }
        
        // Update UI with user info
        updateUserInfo();
        
        // Load workspaces
        await loadWorkspaces();
        
        // Show app
        document.getElementById('loginPage').classList.remove('active');
        document.getElementById('registerPage').classList.remove('active');
        document.getElementById('appPage').classList.add('active');
        
        showToast(`Welcome back, ${APP_STATE.user.first_name || APP_STATE.user.username}!`, 'success');
        
    } catch (error) {
        console.error('Error loading app:', error);
        showToast('Failed to load app', 'error');
        
        // If unauthorized, logout
        if (error.status === 401) {
            api.clearTokens();
            showLoginPage();
        }
    } finally {
        showLoading(false);
    }
}

// Update user info in UI
function updateUserInfo() {
    const userName = document.getElementById('userName');
    if (userName) {
        userName.textContent = APP_STATE.user.full_name || APP_STATE.user.username;
    }
}

// Load workspaces
async function loadWorkspaces() {
    try {
        const workspaces = await api.getWorkspaces();
        APP_STATE.workspaces = workspaces;
        
        if (workspaces.length === 0) {
            showToast('No workspaces found. Create or join one!', 'info');
            showCreateWorkspacePrompt();
            return;
        }
        
        // Load first workspace by default
        const currentWorkspaceId = localStorage.getItem(STORAGE_KEYS.CURRENT_WORKSPACE);
        const workspace = workspaces.find(w => w.id === currentWorkspaceId) || workspaces[0];
        
        await loadWorkspaceData(workspace.id);
        
    } catch (error) {
        console.error('Error loading workspaces:', error);
        showToast('Failed to load workspaces', 'error');
    }
}

// Load workspace data
async function loadWorkspaceData(workspaceId) {
    showLoading(true);
    
    try {
        // Get workspace details
        const workspace = await api.getWorkspace(workspaceId);
        APP_STATE.currentWorkspace = workspace;
        localStorage.setItem(STORAGE_KEYS.CURRENT_WORKSPACE, workspaceId);
        
        // Update UI
        document.getElementById('currentWorkspace').textContent = workspace.name;
        
        // Load channels
        const channels = await api.getChannels(workspaceId);
        APP_STATE.channels = channels;
        
        // Load channels to sidebar
        loadChannelsToSidebar(channels);
        
        // Select first channel or general
        const currentChannelId = localStorage.getItem(STORAGE_KEYS.CURRENT_CHANNEL);
        const channel = channels.find(c => c.id === currentChannelId) || 
                       channels.find(c => c.name === 'general') || 
                       channels[0];
        
        if (channel) {
            await selectChannelWithoutWS(channel.id);
        }
        
    } catch (error) {
        console.error('Error loading workspace data:', error);
        showToast('Failed to load workspace', 'error');
    } finally {
        showLoading(false);
    }
}

// Select channel WITHOUT WebSocket (avoid hanging)
async function selectChannelWithoutWS(channelId) {
    try {
        // Get channel details
        const channel = await api.getChannel(channelId);
        APP_STATE.currentChannel = channel;
        localStorage.setItem(STORAGE_KEYS.CURRENT_CHANNEL, channelId);
        
        // Update UI
        document.getElementById('channelName').textContent = 
            (channel.channel_type === 'private' ? '🔒 ' : '# ') + channel.name;
        document.getElementById('channelTopic').textContent = channel.description || 'No description';
        
        // Update active state in sidebar
        document.querySelectorAll('.channel-item').forEach(item => {
            item.classList.remove('active');
            if (item.dataset.channelId === channelId) {
                item.classList.add('active');
            }
        });
        
        // Load messages
        await loadMessages(channelId);
        
        // Show info about WebSocket
        showToast('💡 Real-time chat requires WebSocket. Messages will refresh on page reload.', 'info');
        
    } catch (error) {
        console.error('Error selecting channel:', error);
        showToast('Failed to load channel', 'error');
    }
}

// Select channel (with WebSocket)
async function selectChannel(channelId) {
    try {
        // Disconnect from current channel WebSocket
        if (wsManager && wsManager.isConnected()) {
            wsManager.disconnect();
        }
        
        await selectChannelWithoutWS(channelId);
        
        // Try connect WebSocket (non-blocking)
        setTimeout(() => {
            if (wsManager) {
                wsManager.connect(channelId);
            }
        }, 100);
        
    } catch (error) {
        console.error('Error selecting channel:', error);
        showToast('Failed to load channel', 'error');
    }
}

// Send message
function sendMessage() {
    const input = document.getElementById('messageInput');
    const text = input.value.trim();
    
    if (!text) return;
    
    if (!APP_STATE.currentChannel) {
        showToast('No channel selected', 'error');
        return;
    }
    
    // Try WebSocket first
    if (wsManager && wsManager.isConnected()) {
        const sent = wsManager.sendMessage(text);
        
        if (sent) {
            input.value = '';
            wsManager.sendTyping(false);
            return;
        }
    }
    
    // Fallback to API
    sendMessageViaAPI(text);
}

// Send message via REST API
async function sendMessageViaAPI(text) {
    const input = document.getElementById('messageInput');
    
    try {
        const message = await api.sendMessage(APP_STATE.currentChannel.id, text);
        
        // Add to UI
        addMessageToUI(message);
        
        input.value = '';
        showToast('Message sent!', 'success');
        
    } catch (error) {
        console.error('Error sending message:', error);
        showToast('Failed to send message', 'error');
    }
}

// Handle message input typing
let typingTimer;
const messageInput = document.getElementById('messageInput');

if (messageInput) {
    messageInput.addEventListener('input', () => {
        if (!wsManager || !wsManager.isConnected()) return;
        
        wsManager.sendTyping(true);
        clearTimeout(typingTimer);
        
        typingTimer = setTimeout(() => {
            wsManager.sendTyping(false);
        }, 2000);
    });
    
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
}

// Show create workspace prompt
function showCreateWorkspacePrompt() {
    showModal('Create Workspace', `
        <form id="createWorkspaceForm">
            <div class="form-group">
                <label>Workspace Name</label>
                <input type="text" id="workspaceName" required placeholder="My Team">
            </div>
            
            <div class="form-group">
                <label>Description (optional)</label>
                <textarea id="workspaceDescription" rows="3"></textarea>
            </div>
            
            <button type="submit" class="btn btn-primary btn-block">
                <i class="fas fa-plus"></i> Create Workspace
            </button>
        </form>
    `);
    
    document.getElementById('createWorkspaceForm').onsubmit = async (e) => {
        e.preventDefault();
        
        const data = {
            name: document.getElementById('workspaceName').value,
            description: document.getElementById('workspaceDescription').value,
            is_public: false
        };
        
        try {
            const workspace = await api.createWorkspace(data);
            showToast('Workspace created successfully!', 'success');
            closeModal();
            
            await loadWorkspaces();
            
        } catch (error) {
            console.error('Error creating workspace:', error);
            showToast('Failed to create workspace', 'error');
        }
    };
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    console.log('📱 DOM loaded, initializing app...');
    
    // Add loading timeout
    setTimeout(() => {
        const loadingScreen = document.getElementById('loadingScreen');
        if (loadingScreen && !loadingScreen.classList.contains('hidden')) {
            console.warn('⚠️ Loading timeout, forcing login page');
            showLoginPage();
        }
    }, 2000); // 2 second timeout
    
    initApp();
});

// Handle visibility change
document.addEventListener('visibilitychange', () => {
    if (!document.hidden && APP_STATE.currentChannel) {
        if (wsManager && !wsManager.isConnected()) {
            console.log('🔄 Page visible, reconnecting WebSocket...');
            wsManager.connect(APP_STATE.currentChannel.id);
        }
    }
});

console.log('✅ Main app loaded');
