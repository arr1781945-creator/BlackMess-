// Mention Autocomplete System

class MentionAutocomplete {
    constructor(inputElement) {
        this.input = inputElement;
        this.dropdown = null;
        this.users = [];
        this.selectedIndex = -1;
        this.mentionStart = -1;
        this.isOpen = false;
        
        this.setupEventListeners();
    }

    // Setup event listeners
    setupEventListeners() {
        this.input.addEventListener('input', (e) => this.handleInput(e));
        this.input.addEventListener('keydown', (e) => this.handleKeydown(e));
        
        // Close dropdown on outside click
        document.addEventListener('click', (e) => {
            if (this.isOpen && !this.dropdown?.contains(e.target) && e.target !== this.input) {
                this.close();
            }
        });
    }

    // Handle input
    async handleInput(e) {
        const text = this.input.value;
        const cursorPos = this.input.selectionStart;
        
        // Find @ symbol before cursor
        const textBeforeCursor = text.substring(0, cursorPos);
        const lastAtIndex = textBeforeCursor.lastIndexOf('@');
        
        if (lastAtIndex === -1) {
            this.close();
            return;
        }
        
        // Check if @ is at start or after space
        const charBeforeAt = lastAtIndex > 0 ? text[lastAtIndex - 1] : ' ';
        if (charBeforeAt !== ' ' && charBeforeAt !== '\n') {
            this.close();
            return;
        }
        
        // Get search query after @
        const query = textBeforeCursor.substring(lastAtIndex + 1);
        
        // Check if there's a space after @ (mention ended)
        if (query.includes(' ')) {
            this.close();
            return;
        }
        
        this.mentionStart = lastAtIndex;
        
        // Search users
        if (query.length >= 1) {
            await this.searchUsers(query);
        } else {
            // Show recent users or all workspace members
            await this.loadWorkspaceMembers();
        }
    }

    // Handle keydown
    handleKeydown(e) {
        if (!this.isOpen) return;
        
        switch (e.key) {
            case 'ArrowDown':
                e.preventDefault();
                this.selectedIndex = Math.min(this.selectedIndex + 1, this.users.length - 1);
                this.updateSelection();
                break;
                
            case 'ArrowUp':
                e.preventDefault();
                this.selectedIndex = Math.max(this.selectedIndex - 1, 0);
                this.updateSelection();
                break;
                
            case 'Enter':
            case 'Tab':
                if (this.selectedIndex >= 0) {
                    e.preventDefault();
                    this.selectUser(this.users[this.selectedIndex]);
                }
                break;
                
            case 'Escape':
                e.preventDefault();
                this.close();
                break;
        }
    }

    // Search users
    async searchUsers(query) {
        try {
            const workspaceId = APP_STATE.currentWorkspace?.id;
            const params = new URLSearchParams({
                q: query,
                ...(workspaceId && { workspace: workspaceId })
            });
            
            const response = await api.get(`/api/auth/search/?${params}`);
            this.users = response;
            this.selectedIndex = 0;
            this.show();
            
        } catch (error) {
            console.error('Error searching users:', error);
        }
    }

    // Load workspace members
    async loadWorkspaceMembers() {
        if (!APP_STATE.currentWorkspace) return;
        
        try {
            const response = await api.get(
                `/api/auth/workspace/${APP_STATE.currentWorkspace.id}/members/`
            );
            this.users = response.slice(0, 10); // Limit to 10
            this.selectedIndex = 0;
            this.show();
            
        } catch (error) {
            console.error('Error loading members:', error);
        }
    }

    // Show dropdown
    show() {
        if (this.users.length === 0) {
            this.close();
            return;
        }
        
        if (!this.dropdown) {
            this.createDropdown();
        }
        
        this.renderUsers();
        this.positionDropdown();
        this.isOpen = true;
    }

    // Create dropdown element
    createDropdown() {
        this.dropdown = document.createElement('div');
        this.dropdown.className = 'mention-dropdown';
        document.body.appendChild(this.dropdown);
    }

    // Render users
    renderUsers() {
        if (!this.dropdown) return;
        
        this.dropdown.innerHTML = this.users.map((user, index) => {
            const fullName = user.full_name || user.username;
            const initials = getUserInitials(fullName);
            
            return `
                <div class="mention-item ${index === this.selectedIndex ? 'selected' : ''}" 
                     data-index="${index}"
                     onmouseenter="mentionAutocomplete.selectedIndex = ${index}; mentionAutocomplete.updateSelection();"
                     onclick="mentionAutocomplete.selectUser(mentionAutocomplete.users[${index}])">
                    <div class="mention-avatar" style="background: ${generateColorFromString(user.id)}">
                        ${initials}
                    </div>
                    <div class="mention-info">
                        <div class="mention-name">${escapeHTML(fullName)}</div>
                        <div class="mention-username">@${escapeHTML(user.username)}</div>
                    </div>
                </div>
            `;
        }).join('');
    }

    // Update selection
    updateSelection() {
        if (!this.dropdown) return;
        
        const items = this.dropdown.querySelectorAll('.mention-item');
        items.forEach((item, index) => {
            if (index === this.selectedIndex) {
                item.classList.add('selected');
                item.scrollIntoView({ block: 'nearest' });
            } else {
                item.classList.remove('selected');
            }
        });
    }

    // Position dropdown
    positionDropdown() {
        if (!this.dropdown) return;
        
        // Get input position
        const rect = this.input.getBoundingClientRect();
        
        // Position below input
        this.dropdown.style.position = 'fixed';
        this.dropdown.style.left = rect.left + 'px';
        this.dropdown.style.bottom = (window.innerHeight - rect.top + 5) + 'px';
        this.dropdown.style.width = Math.min(rect.width, 300) + 'px';
    }

    // Select user
    selectUser(user) {
        const text = this.input.value;
        const beforeMention = text.substring(0, this.mentionStart);
        const afterCursor = text.substring(this.input.selectionStart);
        
        // Insert mention
        const mention = `@${user.username} `;
        this.input.value = beforeMention + mention + afterCursor;
        
        // Set cursor position
        const newCursorPos = beforeMention.length + mention.length;
        this.input.setSelectionRange(newCursorPos, newCursorPos);
        
        // Store mentioned user for sending
        if (!this.input.mentionedUsers) {
            this.input.mentionedUsers = [];
        }
        this.input.mentionedUsers.push(user.id);
        
        this.close();
        this.input.focus();
    }

    // Close dropdown
    close() {
        if (this.dropdown) {
            this.dropdown.remove();
            this.dropdown = null;
        }
        this.isOpen = false;
        this.selectedIndex = -1;
        this.mentionStart = -1;
    }
}

// Initialize mention autocomplete for message input
let mentionAutocomplete;

document.addEventListener('DOMContentLoaded', () => {
    const messageInput = document.getElementById('messageInput');
    if (messageInput) {
        mentionAutocomplete = new MentionAutocomplete(messageInput);
    }
});

// Also initialize for thread input when thread opens
const originalShowThreadSidebar = ThreadManager.prototype.showThreadSidebar;
ThreadManager.prototype.showThreadSidebar = function(threadData) {
    originalShowThreadSidebar.call(this, threadData);
    
    // Initialize mention autocomplete for thread input
    setTimeout(() => {
        const threadInput = document.getElementById('threadReplyInput');
        if (threadInput && !threadInput.mentionAutocomplete) {
            threadInput.mentionAutocomplete = new MentionAutocomplete(threadInput);
        }
    }, 100);
};

console.log('✅ Mention autocomplete loaded');
