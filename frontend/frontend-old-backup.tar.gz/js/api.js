// API Helper Class
class API {
    constructor() {
        this.baseURL = API_CONFIG.BASE_URL;
        this.timeout = API_CONFIG.TIMEOUT;
    }

    // Get auth token
    getToken() {
        return localStorage.getItem(STORAGE_KEYS.ACCESS_TOKEN);
    }

    // Set auth token
    setToken(token) {
        localStorage.setItem(STORAGE_KEYS.ACCESS_TOKEN, token);
    }

    // Get refresh token
    getRefreshToken() {
        return localStorage.getItem(STORAGE_KEYS.REFRESH_TOKEN);
    }

    // Set refresh token
    setRefreshToken(token) {
        localStorage.setItem(STORAGE_KEYS.REFRESH_TOKEN, token);
    }

    // Clear tokens
    clearTokens() {
        localStorage.removeItem(STORAGE_KEYS.ACCESS_TOKEN);
        localStorage.removeItem(STORAGE_KEYS.REFRESH_TOKEN);
        localStorage.removeItem(STORAGE_KEYS.USER_DATA);
    }

    // Build headers
    getHeaders(includeAuth = true) {
        const headers = {
            'Content-Type': 'application/json',
        };

        if (includeAuth) {
            const token = this.getToken();
            if (token) {
                headers['Authorization'] = `Bearer ${token}`;
            }
        }

        return headers;
    }

    // Generic request method
    async request(url, options = {}) {
        const config = {
            ...options,
            headers: this.getHeaders(options.auth !== false),
        };

        try {
            const response = await fetch(this.baseURL + url, config);
            
            // Handle 401 - Try to refresh token
            if (response.status === 401 && this.getRefreshToken()) {
                const refreshed = await this.refreshAccessToken();
                if (refreshed) {
                    // Retry original request
                    config.headers['Authorization'] = `Bearer ${this.getToken()}`;
                    return await fetch(this.baseURL + url, config);
                }
            }

            const data = await response.json().catch(() => ({}));

            if (!response.ok) {
                throw {
                    status: response.status,
                    message: data.error || data.detail || 'Request failed',
                    data: data
                };
            }

            return data;
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    }

    // Refresh access token
    async refreshAccessToken() {
        try {
            const response = await fetch(this.baseURL + API_ENDPOINTS.REFRESH_TOKEN, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    refresh: this.getRefreshToken()
                })
            });

            if (response.ok) {
                const data = await response.json();
                this.setToken(data.access);
                return true;
            }

            this.clearTokens();
            return false;
        } catch (error) {
            this.clearTokens();
            return false;
        }
    }

    // GET request
    async get(url, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        const fullUrl = queryString ? `${url}?${queryString}` : url;
        return this.request(fullUrl, { method: 'GET' });
    }

    // POST request
    async post(url, data = {}) {
        return this.request(url, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }

    // PUT request
    async put(url, data = {}) {
        return this.request(url, {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    }

    // DELETE request
    async delete(url) {
        return this.request(url, { method: 'DELETE' });
    }

    // ===== AUTH ENDPOINTS =====
    
    async login(email, password) {
        const data = await this.post(API_ENDPOINTS.LOGIN, { email, password });
        this.setToken(data.tokens.access);
        this.setRefreshToken(data.tokens.refresh);
        localStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(data.user));
        APP_STATE.user = data.user;
        return data;
    }

    async register(userData) {
        const data = await this.post(API_ENDPOINTS.REGISTER, userData);
        this.setToken(data.tokens.access);
        this.setRefreshToken(data.tokens.refresh);
        localStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(data.user));
        APP_STATE.user = data.user;
        return data;
    }

    async getProfile() {
        return this.get(API_ENDPOINTS.PROFILE);
    }

    logout() {
        this.clearTokens();
        APP_STATE.user = null;
        APP_STATE.currentWorkspace = null;
        APP_STATE.currentChannel = null;
        window.location.reload();
    }

    // ===== WORKSPACE ENDPOINTS =====
    
    async getWorkspaces() {
        return this.get(API_ENDPOINTS.WORKSPACES);
    }

    async getWorkspace(id) {
        return this.get(API_ENDPOINTS.WORKSPACE_DETAIL(id));
    }

    async createWorkspace(data) {
        return this.post(API_ENDPOINTS.WORKSPACES, data);
    }

    async joinWorkspace(id) {
        return this.post(API_ENDPOINTS.WORKSPACE_JOIN(id));
    }

    async getWorkspaceMembers(id) {
        return this.get(API_ENDPOINTS.WORKSPACE_MEMBERS(id));
    }

    // ===== CHANNEL ENDPOINTS =====
    
    async getChannels(workspaceId) {
        return this.get(API_ENDPOINTS.CHANNELS, { workspace: workspaceId });
    }

    async getChannel(id) {
        return this.get(API_ENDPOINTS.CHANNEL_DETAIL(id));
    }

    async createChannel(data) {
        return this.post(API_ENDPOINTS.CHANNELS, data);
    }

    async joinChannel(id) {
        return this.post(API_ENDPOINTS.CHANNEL_JOIN(id));
    }

    // ===== MESSAGE ENDPOINTS =====
    
    async getMessages(channelId) {
        return this.get(API_ENDPOINTS.MESSAGES, { channel: channelId });
    }

    async sendMessage(channelId, text, parentMessageId = null) {
        return this.post(API_ENDPOINTS.MESSAGES, {
            channel: channelId,
            text: text,
            parent_message_id: parentMessageId
        });
    }

    async reactToMessage(messageId, emoji) {
        return this.post(API_ENDPOINTS.MESSAGE_REACT(messageId), { emoji });
    }

    async pinMessage(messageId) {
        return this.post(API_ENDPOINTS.MESSAGE_PIN(messageId));
    }

    // ===== NOTIFICATION ENDPOINTS =====
    
    async getNotifications() {
        return this.get(API_ENDPOINTS.NOTIFICATIONS);
    }

    async markAllNotificationsRead() {
        return this.post(API_ENDPOINTS.MARK_ALL_READ);
    }
}

// Create global API instance
const api = new API();

console.log('✅ API helper loaded');
