let userData = {};
let workspaceData = {};

// Init
document.addEventListener('DOMContentLoaded', () => {
    showSplash();
});

function showSplash() {
    document.getElementById('splashScreen').innerHTML = Templates.splash();
    setTimeout(() => {
        document.getElementById('splashScreen').classList.add('hidden');
        showLogin();
    }, 2500);
}

function showLogin() {
    const el = document.getElementById('loginScreen');
    el.innerHTML = Templates.login();
    el.classList.remove('hidden');
    
    document.getElementById('loginForm').onsubmit = handleLogin;
}

function showSignup() {
    document.getElementById('loginScreen').classList.add('hidden');
    const el = document.getElementById('signupScreen');
    el.innerHTML = Templates.signup();
    el.classList.remove('hidden');
    
    document.getElementById('signupForm').onsubmit = handleSignup;
}

async function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    try {
        const response = await fetch(`${API_BASE_URL}/auth/login/`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();
        
        if (data.access) {
            localStorage.setItem('access_token', data.access);
            userData = data.user;
            checkWorkspace();
        } else {
            alert('Login failed');
        }
    } catch (error) {
        userData = { name: 'Demo User', email };
        checkWorkspace();
    }
}

async function handleSignup(e) {
    e.preventDefault();
    const name = document.getElementById('signupName').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;

    try {
        const response = await fetch(`${API_BASE_URL}/auth/register/`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                username: email.split('@')[0],
                email, 
                password,
                first_name: name.split(' ')[0]
            })
        });

        if (response.ok) {
            alert('Account created! Please sign in.');
            showLogin();
        }
    } catch (error) {
        alert('Signup failed');
    }
}

function checkWorkspace() {
    const hasWorkspace = localStorage.getItem('workspace_name');
    
    if (hasWorkspace) {
        workspaceData.name = hasWorkspace;
        loadMainApp();
    } else {
        showWorkspaceSetup();
    }
}

function showWorkspaceSetup() {
    document.getElementById('loginScreen').classList.add('hidden');
    document.getElementById('signupScreen').classList.add('hidden');
    
    const el = document.getElementById('workspaceSetup');
    el.innerHTML = Templates.workspaceSetup();
    el.classList.remove('hidden');
    
    document.getElementById('workspaceForm').onsubmit = (e) => {
        e.preventDefault();
        workspaceData.name = document.getElementById('workspaceName').value;
        localStorage.setItem('workspace_name', workspaceData.name);
        loadMainApp();
    };
}

function loadMainApp() {
    document.getElementById('workspaceSetup').classList.add('hidden');
    
    const el = document.getElementById('mainApp');
    el.innerHTML = Templates.mainApp(
        workspaceData.name || localStorage.getItem('workspace_name'),
        userData.name || 'User'
    );
    el.classList.remove('hidden');
    
    setupMessageInput();
}

function setupMessageInput() {
    const input = document.getElementById('messageInput');
    input.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
}

function sendMessage() {
    const input = document.getElementById('messageInput');
    const text = input.value.trim();
    
    if (!text) return;
    
    const view = document.getElementById('messagesView');
    
    if (view.querySelector('div[style*="text-align: center"]')) {
        view.innerHTML = '';
    }
    
    const msg = document.createElement('div');
    msg.style.cssText = 'display: flex; gap: 12px; margin-bottom: 16px;';
    msg.innerHTML = `
        <div style="width: 40px; height: 40px; border-radius: 4px; background: linear-gradient(135deg, #4A154B, #611f69); color: white; display: flex; align-items: center; justify-content: center; font-weight: 700;">
            ${(userData.name || 'U').charAt(0).toUpperCase()}
        </div>
        <div>
            <div style="margin-bottom: 4px;">
                <strong>${userData.name || 'You'}</strong>
                <span style="font-size: 12px; color: #616061; margin-left: 8px;">${new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
            <div>${text}</div>
        </div>
    `;
    
    view.appendChild(msg);
    view.scrollTop = view.scrollHeight;
    input.value = '';
}
