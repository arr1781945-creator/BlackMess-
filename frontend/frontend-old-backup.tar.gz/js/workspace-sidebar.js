// Workspace Quick Access Sidebar

class WorkspaceSidebar {
    constructor() {
        this.isOpen = false;
    }

    // Toggle sidebar
    toggle() {
        const sidebar = document.getElementById('workspaceQuickAccess');
        if (!sidebar) {
            this.create();
        } else {
            this.isOpen = !this.isOpen;
            sidebar.classList.toggle('open');
        }
    }

    // Create sidebar
    create() {
        const sidebar = document.createElement('div');
        sidebar.id = 'workspaceQuickAccess';
        sidebar.className = 'workspace-quick-access';
        
        sidebar.innerHTML = `
            <div class="quick-access-header">
                <h4>Workspaces</h4>
                <button class="btn-icon" onclick="workspaceQuickAccess.toggle()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="quick-access-list" id="quickAccessList">
                <div class="loading-text">Loading...</div>
            </div>
            <div class="quick-access-footer">
                <button class="btn btn-sm btn-block" onclick="workspaceSwitcher.showCreateWorkspace()">
                    <i class="fas fa-plus"></i> New Workspace
                </button>
            </div>
        `;
        
        document.body.appendChild(sidebar);
        this.isOpen = true;
        sidebar.classList.add('open');
        
        this.render();
    }

    // Render workspaces
    render() {
        const list = document.getElementById('quickAccessList');
        if (!list || !workspaceSwitcher.workspaces) return;
        
        const items = workspaceSwitcher.workspaces.map(ws => {
            const isActive = APP_STATE.currentWorkspace?.id === ws.id;
            const initials = workspaceSwitcher.getWorkspaceInitials(ws.name);
            
            return `
                <div class="quick-workspace-item ${isActive ? 'active' : ''}" 
                     onclick="workspaceSwitcher.switchTo('${ws.id}'); workspaceQuickAccess.toggle();">
                    <div class="workspace-icon-sm" style="background: ${generateColorFromString(ws.id)}">
                        ${initials}
                    </div>
                    <span>${escapeHTML(ws.name)}</span>
                </div>
            `;
        }).join('');
        
        list.innerHTML = items;
    }
}

// Create global instance
const workspaceQuickAccess = new WorkspaceSidebar();

console.log('✅ Workspace sidebar loaded');
