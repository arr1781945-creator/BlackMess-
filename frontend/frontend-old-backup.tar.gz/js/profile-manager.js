// Profile Manager

class ProfileManager {
    constructor() {
        this.currentProfile = null;
    }

    // Show profile editor
    async showEditor() {
        showLoading(true);
        
        try {
            const profile = await api.get('/api/auth/profile/detail/');
            this.currentProfile = profile;
            
            this.renderEditor(profile);
            
        } catch (error) {
            console.error('Error loading profile:', error);
            showToast('Failed to load profile', 'error');
        } finally {
            showLoading(false);
        }
    }

    // Render profile editor
    renderEditor(profile) {
        const initials = getUserInitials(profile.full_name || profile.username);
        const avatarBg = generateColorFromString(profile.id);
        
        showModal('Edit Profile', `
            <div class="profile-editor">
                <!-- Avatar Section -->
                <div class="avatar-section">
                    <div class="current-avatar" id="currentAvatar" style="background: ${avatarBg}">
                        ${profile.profile?.avatar ? 
                            `<img src="${profile.profile.avatar}" alt="Avatar">` : 
                            initials
                        }
                    </div>
                    <div class="avatar-actions">
                        <button class="btn btn-sm" onclick="profileManager.changeAvatar()">
                            <i class="fas fa-camera"></i> Change Photo
                        </button>
                        <button class="btn btn-sm" onclick="profileManager.removeAvatar()">
                            <i class="fas fa-trash"></i> Remove
                        </button>
                    </div>
                </div>

                <!-- Profile Form -->
                <form id="profileForm" class="profile-form">
                    <div class="form-row">
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" id="firstName" value="${profile.first_name || ''}" required>
                        </div>
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" id="lastName" value="${profile.last_name || ''}">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" id="username" value="${profile.username}" required>
                    </div>

                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" value="${profile.email}" disabled>
                        <small>Email cannot be changed</small>
                    </div>

                    <div class="form-group">
                        <label>Bio</label>
                        <textarea id="bio" rows="3" placeholder="Tell us about yourself...">${profile.profile?.bio || ''}</textarea>
                    </div>

                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="tel" id="phoneNumber" value="${profile.profile?.phone_number || ''}" placeholder="+1 234 567 8900">
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>City</label>
                            <input type="text" id="city" value="${profile.profile?.city || ''}" placeholder="San Francisco">
                        </div>
                        <div class="form-group">
                            <label>Country</label>
                            <input type="text" id="country" value="${profile.profile?.country || ''}" placeholder="United States">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Timezone</label>
                        <select id="timezone">
                            ${this.getTimezoneOptions(profile.profile?.timezone)}
                        </select>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary btn-block">
                            <i class="fas fa-save"></i> Save Changes
                        </button>
                        <button type="button" class="btn btn-block" onclick="closeModal()">
                            Cancel
                        </button>
                    </div>
                </form>
            </div>
        `);

        // Handle form submit
        document.getElementById('profileForm').onsubmit = (e) => {
            e.preventDefault();
            this.saveProfile();
        };
    }

    // Get timezone options
    getTimezoneOptions(selected = 'UTC') {
        const timezones = [
            'UTC',
            'America/New_York',
            'America/Chicago',
            'America/Denver',
            'America/Los_Angeles',
            'Europe/London',
            'Europe/Paris',
            'Asia/Tokyo',
            'Asia/Shanghai',
            'Asia/Singapore',
            'Asia/Jakarta',
            'Australia/Sydney',
        ];

        return timezones.map(tz => 
            `<option value="${tz}" ${tz === selected ? 'selected' : ''}>${tz}</option>`
        ).join('');
    }

    // Save profile
    async saveProfile() {
        const data = {
            first_name: document.getElementById('firstName').value,
            last_name: document.getElementById('lastName').value,
            username: document.getElementById('username').value,
            profile: {
                bio: document.getElementById('bio').value,
                phone_number: document.getElementById('phoneNumber').value,
                city: document.getElementById('city').value,
                country: document.getElementById('country').value,
                timezone: document.getElementById('timezone').value,
            }
        };

        showLoading(true);

        try {
            const response = await api.put('/api/auth/profile/detail/', data);
            
            // Update app state
            APP_STATE.user = response.user;
            localStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(response.user));
            
            // Update UI
            updateUserInfo();
            
            showToast('Profile updated successfully!', 'success');
            closeModal();
            
        } catch (error) {
            console.error('Error saving profile:', error);
            showToast('Failed to save profile', 'error');
        } finally {
            showLoading(false);
        }
    }

    // Change avatar
    changeAvatar() {
        showModal('Change Avatar', `
            <div class="avatar-options">
                <h4>Choose Avatar Method</h4>
                
                <button class="avatar-method" onclick="profileManager.uploadAvatar()">
                    <i class="fas fa-upload fa-2x"></i>
                    <h5>Upload Photo</h5>
                    <p>Upload from your device</p>
                </button>
                
                <button class="avatar-method" onclick="profileManager.useGravatar()">
                    <i class="fas fa-globe fa-2x"></i>
                    <h5>Use Gravatar</h5>
                    <p>Use your Gravatar image</p>
                </button>
                
                <button class="avatar-method" onclick="profileManager.generateAvatar()">
                    <i class="fas fa-dice fa-2x"></i>
                    <h5>Generate Avatar</h5>
                    <p>Create a unique avatar</p>
                </button>
            </div>
        `);
    }

    // Upload avatar
    uploadAvatar() {
        showToast('Avatar upload coming soon!', 'info');
        // TODO: Implement file upload
        closeModal();
    }

    // Use Gravatar
    useGravatar() {
        const email = APP_STATE.user.email;
        const hash = this.md5(email.toLowerCase().trim());
        const avatarUrl = `https://www.gravatar.com/avatar/${hash}?s=200&d=identicon`;
        
        this.setAvatar(avatarUrl);
    }

    // Generate avatar (using DiceBear API)
    generateAvatar() {
        const seed = APP_STATE.user.username;
        const avatarUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=${seed}`;
        
        this.setAvatar(avatarUrl);
    }

    // Set avatar
    async setAvatar(avatarUrl) {
        showLoading(true);
        
        try {
            await api.post('/api/auth/profile/avatar/', {
                avatar_url: avatarUrl
            });
            
            // Update current profile
            if (this.currentProfile) {
                this.currentProfile.profile = this.currentProfile.profile || {};
                this.currentProfile.profile.avatar = avatarUrl;
            }
            
            // Update UI
            const avatarDiv = document.getElementById('currentAvatar');
            if (avatarDiv) {
                avatarDiv.innerHTML = `<img src="${avatarUrl}" alt="Avatar">`;
            }
            
            showToast('Avatar updated!', 'success');
            closeModal();
            
        } catch (error) {
            console.error('Error setting avatar:', error);
            showToast('Failed to update avatar', 'error');
        } finally {
            showLoading(false);
        }
    }

    // Remove avatar
    async removeAvatar() {
        if (!confirm('Remove your avatar?')) return;
        
        await this.setAvatar('');
        
        // Regenerate initials
        const avatarDiv = document.getElementById('currentAvatar');
        if (avatarDiv && this.currentProfile) {
            const initials = getUserInitials(this.currentProfile.full_name || this.currentProfile.username);
            const bg = generateColorFromString(this.currentProfile.id);
            avatarDiv.style.background = bg;
            avatarDiv.innerHTML = initials;
        }
    }

    // MD5 hash for Gravatar
    md5(str) {
        // Simple MD5 implementation (you might want to use a library)
        // For now, return a placeholder
        return str.split('').reduce((a, b) => {
            a = ((a << 5) - a) + b.charCodeAt(0);
            return a & a;
        }, 0).toString(16);
    }

    // Show status editor
    showStatusEditor() {
        const currentStatus = 'active'; // Get from workspace member
        const currentText = '';
        
        showModal('Set Status', `
            <div class="status-editor">
                <div class="status-options">
                    <button class="status-option ${currentStatus === 'active' ? 'active' : ''}" 
                            onclick="profileManager.selectStatus('active', '🟢')">
                        🟢 Active
                    </button>
                    <button class="status-option ${currentStatus === 'away' ? 'active' : ''}" 
                            onclick="profileManager.selectStatus('away', '🟡')">
                        🟡 Away
                    </button>
                    <button class="status-option ${currentStatus === 'dnd' ? 'active' : ''}" 
                            onclick="profileManager.selectStatus('dnd', '🔴')">
                        🔴 Do Not Disturb
                    </button>
                </div>

                <div class="form-group">
                    <label>Status Message</label>
                    <input type="text" id="statusText" placeholder="What's your status?" value="${currentText}" maxlength="100">
                    <small>Let people know what you're up to</small>
                </div>

                <div class="status-presets">
                    <button class="preset-btn" onclick="document.getElementById('statusText').value='In a meeting'">
                        📅 In a meeting
                    </button>
                    <button class="preset-btn" onclick="document.getElementById('statusText').value='Working remotely'">
                        🏠 Working remotely
                    </button>
                    <button class="preset-btn" onclick="document.getElementById('statusText').value='On vacation'">
                        🌴 On vacation
                    </button>
                    <button class="preset-btn" onclick="document.getElementById('statusText').value='Focusing'">
                        🎯 Focusing
                    </button>
                </div>

                <button class="btn btn-primary btn-block" onclick="profileManager.saveStatus()">
                    <i class="fas fa-check"></i> Update Status
                </button>
            </div>
        `);
    }

    // Select status
    selectStatus(status, emoji) {
        document.querySelectorAll('.status-option').forEach(btn => {
            btn.classList.remove('active');
        });
        event.target.classList.add('active');
        
        this.selectedStatus = status;
    }

    // Save status
    async saveStatus() {
        const statusText = document.getElementById('statusText').value;
        const status = this.selectedStatus || 'active';
        
        try {
            await api.post('/api/auth/profile/status/', {
                status: status,
                status_text: statusText
            });
            
            showToast('Status updated!', 'success');
            closeModal();
            
            // Broadcast via WebSocket
            if (wsManager.isConnected()) {
                wsManager.updatePresence(status, statusText);
            }
            
        } catch (error) {
            console.error('Error updating status:', error);
            showToast('Failed to update status', 'error');
        }
    }
}

// Create global instance
const profileManager = new ProfileManager();

// Update showProfile function
function showProfile() {
    profileManager.showEditor();
}

console.log('✅ Profile manager loaded');
