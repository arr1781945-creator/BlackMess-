// Online Users Manager

class OnlineUsersManager {
    constructor() {
        this.onlineUsers = new Map();
        this.updateInterval = null;
    }

    // Initialize
    init() {
        this.startHeartbeat();
    }

    // Add user to online list
    addUser(user) {
        this.onlineUsers.set(user.id, {
            ...user,
            lastSeen: new Date()
        });
        this.render();
    }

    // Remove user from online list
    removeUser(userId) {
        this.onlineUsers.delete(userId);
        this.render();
    }

    // Update user status
    updateUserStatus(userId, status, statusText = '') {
        const user = this.onlineUsers.get(userId);
        if (user) {
            user.status = status;
            user.status_text = statusText;
            user.lastSeen = new Date();
            this.render();
        }
    }

    // Set online users list
    setUsers(users) {
        this.onlineUsers.clear();
        users.forEach(user => {
            this.onlineUsers.set(user.id, {
                ...user,
                lastSeen: new Date()
            });
        });
        this.render();
    }

    // Render online users
    render() {
        const container = document.getElementById('onlineUsersList');
        if (!container) return;

        const users = Array.from(this.onlineUsers.values());
        
        if (users.length === 0) {
            container.innerHTML = '<div class="empty-state">No one else is online</div>';
            return;
        }

        // Sort by status (active first) then by name
        users.sort((a, b) => {
            const statusOrder = { active: 0, away: 1, dnd: 2, offline: 3 };
            const statusDiff = (statusOrder[a.status] || 3) - (statusOrder[b.status] || 3);
            if (statusDiff !== 0) return statusDiff;
            
            const nameA = (a.full_name || a.username).toLowerCase();
            const nameB = (b.full_name || b.username).toLowerCase();
            return nameA.localeCompare(nameB);
        });

        container.innerHTML = users.map(user => this.renderUser(user)).join('');
        
        // Update badge count
        this.updateBadge(users.length);
    }

    // Render single user
    renderUser(user) {
        const initials = getUserInitials(user.full_name || user.username);
        const statusIcon = this.getStatusIcon(user.status);
        const statusColor = this.getStatusColor(user.status);
        
        return `
            <div class="online-user-item" data-user-id="${user.id}">
                <div class="online-user-avatar" style="background: ${generateColorFromString(user.id)}">
                    ${initials}
                    <span class="status-indicator" style="background: ${statusColor}"></span>
                </div>
                <div class="online-user-info">
                    <div class="online-user-name">
                        ${escapeHTML(user.full_name || user.username)}
                    </div>
                    <div class="online-user-status">
                        ${statusIcon} ${this.getStatusText(user)}
                    </div>
                </div>
                <button class="btn-icon" onclick="onlineUsers.startDM('${user.id}')" title="Send message">
                    <i class="fas fa-comment"></i>
                </button>
            </div>
        `;
    }

    // Get status icon
    getStatusIcon(status) {
        const icons = {
            active: '<i class="fas fa-circle"></i>',
            away: '<i class="fas fa-clock"></i>',
            dnd: '<i class="fas fa-minus-circle"></i>',
            offline: '<i class="far fa-circle"></i>'
        };
        return icons[status] || icons.offline;
    }

    // Get status color
    getStatusColor(status) {
        const colors = {
            active: '#10b981',
            away: '#f59e0b',
            dnd: '#ef4444',
            offline: '#9ca3af'
        };
        return colors[status] || colors.offline;
    }

    // Get status text
    getStatusText(user) {
        if (user.status_text) {
            return user.status_text;
        }
        
        const statusTexts = {
            active: 'Active',
            away: 'Away',
            dnd: 'Do not disturb',
            offline: 'Offline'
        };
        return statusTexts[user.status] || 'Offline';
    }

    // Update badge count
    updateBadge(count) {
        const badge = document.getElementById('onlineUsersBadge');
        if (badge) {
            badge.textContent = count;
            badge.style.display = count > 0 ? 'inline-block' : 'none';
        }
    }

    // Start DM with user
    startDM(userId) {
        showToast('Direct messages coming soon!', 'info');
        // TODO: Implement DM creation
    }

    // Toggle online users panel
    toggle() {
        const panel = document.getElementById('onlineUsersPanel');
        if (panel) {
            panel.classList.toggle('open');
        }
    }

    // Start heartbeat to remove stale users
    startHeartbeat() {
        this.updateInterval = setInterval(() => {
            const now = new Date();
            const staleTimeout = 5 * 60 * 1000; // 5 minutes
            
            this.onlineUsers.forEach((user, userId) => {
                const diff = now - user.lastSeen;
                if (diff > staleTimeout) {
                    this.removeUser(userId);
                }
            });
        }, 60000); // Check every minute
    }

    // Clean up
    destroy() {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
        }
        this.onlineUsers.clear();
    }
}

// Create global instance
const onlineUsers = new OnlineUsersManager();

// Initialize when app loads
document.addEventListener('DOMContentLoaded', () => {
    onlineUsers.init();
});

console.log('✅ Online users manager loaded');

// Update both badges
OnlineUsersManager.prototype.updateBadge = function(count) {
    const badge1 = document.getElementById('onlineUsersBadge');
    const badge2 = document.getElementById('onlineUsersBadge2');
    
    [badge1, badge2].forEach(badge => {
        if (badge) {
            badge.textContent = count;
            badge.style.display = count > 0 ? 'inline-block' : 'none';
        }
    });
};
