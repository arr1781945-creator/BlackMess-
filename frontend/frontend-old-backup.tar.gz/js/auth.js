// Authentication Handler
class Auth {
    constructor() {
        this.api = api;
    }

    // Check if user is authenticated
    isAuthenticated() {
        return !!this.api.getToken();
    }

    // Get current user
    getCurrentUser() {
        const userData = localStorage.getItem(STORAGE_KEYS.USER_DATA);
        return userData ? JSON.parse(userData) : null;
    }

    // Handle login form submit
    async handleLogin(event) {
        event.preventDefault();

        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;

        showLoading(true);

        try {
            const data = await this.api.login(email, password);
            
            showToast('Login successful! Welcome back!', 'success');
            
            // Load app
            setTimeout(() => {
                loadApp();
            }, 500);

        } catch (error) {
            console.error('Login error:', error);
            showToast(error.message || 'Login failed. Please check your credentials.', 'error');
        } finally {
            showLoading(false);
        }
    }

    // Handle register form submit
    async handleRegister(event) {
        event.preventDefault();

        const password = document.getElementById('regPassword').value;
        const passwordConfirm = document.getElementById('regPasswordConfirm').value;

        if (password !== passwordConfirm) {
            showToast('Passwords do not match!', 'error');
            return;
        }

        const userData = {
            username: document.getElementById('regUsername').value,
            email: document.getElementById('regEmail').value,
            password: password,
            password_confirm: passwordConfirm,
            first_name: document.getElementById('regFirstName').value,
            last_name: document.getElementById('regLastName').value,
        };

        showLoading(true);

        try {
            const data = await this.api.register(userData);
            
            showToast('Account created successfully! Welcome!', 'success');
            
            // Load app
            setTimeout(() => {
                loadApp();
            }, 500);

        } catch (error) {
            console.error('Register error:', error);
            
            let errorMsg = 'Registration failed. ';
            if (error.data) {
                const errors = Object.values(error.data).flat();
                errorMsg += errors.join(', ');
            }
            
            showToast(errorMsg, 'error');
        } finally {
            showLoading(false);
        }
    }

    // Logout
    logout() {
        if (confirm('Are you sure you want to logout?')) {
            this.api.logout();
        }
    }
}

// Create global auth instance
const auth = new Auth();

// Show/hide pages
function showLogin() {
    document.getElementById('loginPage').classList.add('active');
    document.getElementById('registerPage').classList.remove('active');
}

function showRegister() {
    document.getElementById('loginPage').classList.remove('active');
    document.getElementById('registerPage').classList.add('active');
}

// Setup auth form listeners
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');

    if (loginForm) {
        loginForm.addEventListener('submit', (e) => auth.handleLogin(e));
    }

    if (registerForm) {
        registerForm.addEventListener('submit', (e) => auth.handleRegister(e));
    }
});

console.log('✅ Auth module loaded');
