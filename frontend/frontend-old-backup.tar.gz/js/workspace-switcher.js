// Workspace Switcher

class WorkspaceSwitcher {
    constructor() {
        this.workspaces = [];
        this.currentWorkspace = null;
    }

    // Initialize
    async init() {
        await this.loadWorkspaces();
    }

    // Load all workspaces
    async loadWorkspaces() {
        try {
            const workspaces = await api.getWorkspaces();
            this.workspaces = workspaces;
            
            // Update sidebar workspace list
            this.renderWorkspaceList();
            
        } catch (error) {
            console.error('Error loading workspaces:', error);
        }
    }

    // Render workspace list in sidebar
    renderWorkspaceList() {
        const selector = document.querySelector('.workspace-selector');
        if (!selector || !APP_STATE.currentWorkspace) return;
        
        const ws = APP_STATE.currentWorkspace;
        selector.innerHTML = `
            <i class="fas fa-building"></i>
            <span>${escapeHTML(ws.name)}</span>
            <i class="fas fa-chevron-down"></i>
        `;
        
        // Add click handler
        selector.onclick = () => this.showSwitcher();
    }

    // Show workspace switcher
    showSwitcher() {
        if (this.workspaces.length === 0) {
            showToast('No workspaces available', 'info');
            return;
        }

        const workspacesList = this.workspaces.map(ws => {
            const isActive = APP_STATE.currentWorkspace?.id === ws.id;
            const initials = this.getWorkspaceInitials(ws.name);
            
            return `
                <div class="workspace-item ${isActive ? 'active' : ''}" 
                     onclick="workspaceSwitcher.switchTo('${ws.id}')">
                    <div class="workspace-icon" style="background: ${generateColorFromString(ws.id)}">
                        ${initials}
                    </div>
                    <div class="workspace-info">
                        <div class="workspace-name">${escapeHTML(ws.name)}</div>
                        <div class="workspace-meta">
                            ${ws.member_count} members
                            ${isActive ? '<span class="active-badge">Active</span>' : ''}
                        </div>
                    </div>
                    ${isActive ? '<i class="fas fa-check"></i>' : ''}
                </div>
            `;
        }).join('');

        showModal('Switch Workspace', `
            <div class="workspace-switcher">
                <div class="workspace-list">
                    ${workspacesList}
                </div>

                <div class="switcher-actions">
                    <button class="btn btn-primary btn-block" onclick="workspaceSwitcher.showCreateWorkspace()">
                        <i class="fas fa-plus"></i> Create New Workspace
                    </button>
                    <button class="btn btn-block" onclick="workspaceSwitcher.showJoinWorkspace()">
                        <i class="fas fa-sign-in-alt"></i> Join Workspace
                    </button>
                </div>
            </div>
        `);
    }

    // Get workspace initials
    getWorkspaceInitials(name) {
        const words = name.trim().split(' ');
        if (words.length >= 2) {
            return (words[0][0] + words[1][0]).toUpperCase();
        }
        return name.substring(0, 2).toUpperCase();
    }

    // Switch to workspace
    async switchTo(workspaceId) {
        if (workspaceId === APP_STATE.currentWorkspace?.id) {
            closeModal();
            return;
        }

        closeModal();
        showLoading(true);

        try {
            // Disconnect from current channel WebSocket
            if (wsManager.isConnected()) {
                wsManager.disconnect();
            }

            // Load new workspace data
            await loadWorkspaceData(workspaceId);
            
            showToast('Switched workspace successfully', 'success');

        } catch (error) {
            console.error('Error switching workspace:', error);
            showToast('Failed to switch workspace', 'error');
        } finally {
            showLoading(false);
        }
    }

    // Show create workspace form
    showCreateWorkspace() {
        closeModal();
        
        showModal('Create Workspace', `
            <div class="create-workspace-form">
                <p class="form-description">
                    Workspaces are where your team communicates. Create one for your organization.
                </p>

                <form id="createWorkspaceForm">
                    <div class="form-group">
                        <label>Workspace Name *</label>
                        <input type="text" id="workspaceName" required 
                               placeholder="e.g., Acme Corp" maxlength="100">
                        <small>This is the name of your company or organization</small>
                    </div>

                    <div class="form-group">
                        <label>Description</label>
                        <textarea id="workspaceDescription" rows="3" 
                                  placeholder="What's this workspace for?"></textarea>
                    </div>

                    <div class="form-group">
                        <label>
                            <input type="checkbox" id="workspacePublic">
                            Make this workspace public
                        </label>
                        <small>Public workspaces can be discovered and joined by anyone</small>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary btn-block">
                            <i class="fas fa-plus"></i> Create Workspace
                        </button>
                        <button type="button" class="btn btn-block" onclick="workspaceSwitcher.showSwitcher()">
                            <i class="fas fa-arrow-left"></i> Back
                        </button>
                    </div>
                </form>
            </div>
        `);

        document.getElementById('createWorkspaceForm').onsubmit = (e) => {
            e.preventDefault();
            this.createWorkspace();
        };
    }

    // Create workspace
    async createWorkspace() {
        const data = {
            name: document.getElementById('workspaceName').value,
            description: document.getElementById('workspaceDescription').value,
            is_public: document.getElementById('workspacePublic').checked
        };

        showLoading(true);

        try {
            const workspace = await api.createWorkspace(data);
            
            showToast('Workspace created successfully!', 'success');
            closeModal();

            // Reload workspaces and switch to new one
            await this.loadWorkspaces();
            await this.switchTo(workspace.id);

        } catch (error) {
            console.error('Error creating workspace:', error);
            showToast('Failed to create workspace', 'error');
        } finally {
            showLoading(false);
        }
    }

    // Show join workspace
    showJoinWorkspace() {
        closeModal();
        
        showModal('Join Workspace', `
            <div class="join-workspace-form">
                <p class="form-description">
                    Enter an invite code or browse public workspaces
                </p>

                <div class="form-group">
                    <label>Invite Code</label>
                    <input type="text" id="inviteCode" placeholder="e.g., ABC123XYZ">
                    <button class="btn btn-primary btn-block" onclick="workspaceSwitcher.joinByCode()">
                        <i class="fas fa-sign-in-alt"></i> Join with Code
                    </button>
                </div>

                <div class="divider">
                    <span>OR</span>
                </div>

                <div id="publicWorkspaces">
                    <h4>Public Workspaces</h4>
                    <div class="loading-text">Loading...</div>
                </div>

                <button class="btn btn-block" onclick="workspaceSwitcher.showSwitcher()">
                    <i class="fas fa-arrow-left"></i> Back
                </button>
            </div>
        `);

        // Load public workspaces
        this.loadPublicWorkspaces();
    }

    // Load public workspaces
    async loadPublicWorkspaces() {
        try {
            // TODO: Add API endpoint for public workspaces
            const publicWs = this.workspaces.filter(ws => ws.is_public);
            
            const container = document.getElementById('publicWorkspaces');
            
            if (publicWs.length === 0) {
                container.innerHTML = '<p class="empty-state">No public workspaces available</p>';
                return;
            }

            const list = publicWs.map(ws => {
                const initials = this.getWorkspaceInitials(ws.name);
                return `
                    <div class="public-workspace-item">
                        <div class="workspace-icon" style="background: ${generateColorFromString(ws.id)}">
                            ${initials}
                        </div>
                        <div class="workspace-info">
                            <div class="workspace-name">${escapeHTML(ws.name)}</div>
                            <div class="workspace-meta">${ws.member_count} members</div>
                        </div>
                        <button class="btn btn-sm btn-primary" onclick="workspaceSwitcher.joinWorkspace('${ws.id}')">
                            Join
                        </button>
                    </div>
                `;
            }).join('');

            container.innerHTML = `<h4>Public Workspaces</h4>${list}`;

        } catch (error) {
            console.error('Error loading public workspaces:', error);
        }
    }

    // Join by code
    async joinByCode() {
        const code = document.getElementById('inviteCode').value.trim();
        
        if (!code) {
            showToast('Please enter an invite code', 'error');
            return;
        }

        showToast('Invite code feature coming soon!', 'info');
        // TODO: Implement invite code joining
    }

    // Join workspace
    async joinWorkspace(workspaceId) {
        showLoading(true);

        try {
            await api.joinWorkspace(workspaceId);
            
            showToast('Joined workspace successfully!', 'success');
            closeModal();

            // Reload workspaces and switch
            await this.loadWorkspaces();
            await this.switchTo(workspaceId);

        } catch (error) {
            console.error('Error joining workspace:', error);
            showToast('Failed to join workspace', 'error');
        } finally {
            showLoading(false);
        }
    }

    // Quick switch (keyboard shortcut)
    quickSwitch() {
        if (this.workspaces.length <= 1) {
            showToast('No other workspaces available', 'info');
            return;
        }

        // Get next workspace in list
        const currentIndex = this.workspaces.findIndex(
            ws => ws.id === APP_STATE.currentWorkspace?.id
        );
        
        const nextIndex = (currentIndex + 1) % this.workspaces.length;
        const nextWorkspace = this.workspaces[nextIndex];

        this.switchTo(nextWorkspace.id);
    }
}

// Create global instance
const workspaceSwitcher = new WorkspaceSwitcher();

// Initialize when app loads
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        if (APP_STATE.user) {
            workspaceSwitcher.init();
        }
    }, 1000);
});

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Ctrl/Cmd + K = Quick switch
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        workspaceSwitcher.showSwitcher();
    }
    
    // Ctrl/Cmd + Shift + K = Quick switch to next workspace
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'K') {
        e.preventDefault();
        workspaceSwitcher.quickSwitch();
    }
});

console.log('✅ Workspace switcher loaded');

// Show keyboard hint on first load
let hintShown = localStorage.getItem('keyboard_hint_shown');

if (!hintShown) {
    setTimeout(() => {
        const hint = document.getElementById('keyboardHint');
        if (hint) {
            hint.classList.add('show');
            
            setTimeout(() => {
                hint.classList.remove('show');
                localStorage.setItem('keyboard_hint_shown', 'true');
            }, 5000);
        }
    }, 3000);
}
