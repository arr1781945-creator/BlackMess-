// UI Helper Functions

// Show/hide loading screen
function showLoading(show = true) {
    const loadingScreen = document.getElementById('loadingScreen');
    if (show) {
        loadingScreen.classList.remove('hidden');
    } else {
        loadingScreen.classList.add('hidden');
    }
}

// Show toast notification
function showToast(message, type = 'info', duration = 3000) {
    const container = document.getElementById('toastContainer');
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icon = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        info: 'fa-info-circle',
        warning: 'fa-exclamation-triangle'
    }[type] || 'fa-info-circle';
    
    toast.innerHTML = `
        <i class="fas ${icon}"></i>
        <span>${message}</span>
    `;
    
    container.appendChild(toast);
    
    // Auto remove after duration
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

// Update connection status
function updateConnectionStatus(connected) {
    const statusIndicator = document.querySelector('.user-status');
    if (statusIndicator) {
        if (connected) {
            statusIndicator.classList.add('online');
            statusIndicator.innerHTML = '<i class="fas fa-circle"></i> Online';
        } else {
            statusIndicator.classList.remove('online');
            statusIndicator.innerHTML = '<i class="fas fa-circle"></i> Offline';
        }
    }
}

// Format timestamp
function formatTime(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    
    // Less than 1 minute
    if (diff < 60000) {
        return 'Just now';
    }
    
    // Less than 1 hour
    if (diff < 3600000) {
        const minutes = Math.floor(diff / 60000);
        return `${minutes}m ago`;
    }
    
    // Less than 24 hours
    if (diff < 86400000) {
        const hours = Math.floor(diff / 3600000);
        return `${hours}h ago`;
    }
    
    // Show time
    const timeStr = date.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
    
    // Same day
    if (date.toDateString() === now.toDateString()) {
        return timeStr;
    }
    
    // Yesterday
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    if (date.toDateString() === yesterday.toDateString()) {
        return `Yesterday ${timeStr}`;
    }
    
    // Other days
    return date.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric' 
    }) + ' ' + timeStr;
}

// Get user initials
function getUserInitials(name) {
    if (!name) return '?';
    const parts = name.trim().split(' ');
    if (parts.length >= 2) {
        return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
}

// Escape HTML
function escapeHTML(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Parse mentions and format text
function formatMessageText(text) {
    let formatted = escapeHTML(text);
    
    // Parse @mentions
    formatted = formatted.replace(/@(\w+)/g, '<span class="mention">@$1</span>');
    
    // Parse URLs
    formatted = formatted.replace(
        /(https?:\/\/[^\s]+)/g, 
        '<a href="$1" target="_blank">$1</a>'
    );
    
    // Parse line breaks
    formatted = formatted.replace(/\n/g, '<br>');
    
    return formatted;
}

// Add message to UI
function addMessageToUI(message) {
    const container = document.getElementById('messagesContainer');
    
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message';
    messageDiv.dataset.messageId = message.id;
    
    const user = message.user;
    const initials = getUserInitials(user.full_name || user.username);
    
    messageDiv.innerHTML = `
        <div class="message-avatar" style="background: ${generateColorFromString(user.id)}">
            ${initials}
        </div>
        <div class="message-content">
            <div class="message-header">
                <span class="message-author">${escapeHTML(user.full_name || user.username)}</span>
                <span class="message-time">${formatTime(message.created_at)}</span>
            </div>
            <div class="message-text">${formatMessageText(message.text)}</div>
            ${message.reactions && message.reactions.length > 0 ? renderReactions(message.reactions) : ''}
            <div class="message-actions">
                <button class="btn-icon" onclick="replyToMessage('${message.id}')" title="Reply in thread">
                    <i class="fas fa-reply"></i>
                </button>
                <button class="btn-icon" onclick="addReaction('${message.id}')" title="Add reaction">
                    <i class="fas fa-smile"></i>
                </button>
                <button class="btn-icon" onclick="showMessageMenu('${message.id}')" title="More">
                    <i class="fas fa-ellipsis-v"></i>
                </button>
            </div>
        </div>
    `;
    
    container.appendChild(messageDiv);
    
    // Scroll to bottom
    container.scrollTop = container.scrollHeight;
}

// Render reactions
function renderReactions(reactions) {
    if (!reactions || reactions.length === 0) return '';
    
    return `
        <div class="message-reactions">
            ${reactions.map(r => `
                <span class="reaction ${r.reacted_by_current_user ? 'active' : ''}" 
                      onclick="toggleReaction('${r.message_id}', '${r.emoji}')">
                    ${r.emoji} ${r.count}
                </span>
            `).join('')}
        </div>
    `;
}

// Update message reaction
function updateMessageReaction(messageId, emoji, userId, action) {
    const messageDiv = document.querySelector(`[data-message-id="${messageId}"]`);
    if (!messageDiv) return;
    
    // Find or create reactions container
    let reactionsDiv = messageDiv.querySelector('.message-reactions');
    if (!reactionsDiv) {
        reactionsDiv = document.createElement('div');
        reactionsDiv.className = 'message-reactions';
        messageDiv.querySelector('.message-text').after(reactionsDiv);
    }
    
    // Update reaction count
    let reactionSpan = reactionsDiv.querySelector(`[data-emoji="${emoji}"]`);
    if (action === 'added') {
        if (reactionSpan) {
            const count = parseInt(reactionSpan.dataset.count) + 1;
            reactionSpan.dataset.count = count;
            reactionSpan.textContent = `${emoji} ${count}`;
        } else {
            reactionSpan = document.createElement('span');
            reactionSpan.className = 'reaction';
            reactionSpan.dataset.emoji = emoji;
            reactionSpan.dataset.count = 1;
            reactionSpan.textContent = `${emoji} 1`;
            reactionsDiv.appendChild(reactionSpan);
        }
    } else {
        if (reactionSpan) {
            const count = parseInt(reactionSpan.dataset.count) - 1;
            if (count <= 0) {
                reactionSpan.remove();
            } else {
                reactionSpan.dataset.count = count;
                reactionSpan.textContent = `${emoji} ${count}`;
            }
        }
    }
}

// Remove message from UI
function removeMessageFromUI(messageId) {
    const messageDiv = document.querySelector(`[data-message-id="${messageId}"]`);
    if (messageDiv) {
        messageDiv.style.opacity = '0';
        setTimeout(() => messageDiv.remove(), 300);
    }
}

// Update message in UI
function updateMessageInUI(message) {
    const messageDiv = document.querySelector(`[data-message-id="${message.id}"]`);
    if (!messageDiv) return;
    
    const textDiv = messageDiv.querySelector('.message-text');
    if (textDiv) {
        textDiv.innerHTML = formatMessageText(message.text) + ' <span class="edited">(edited)</span>';
    }
}

// Generate color from string
function generateColorFromString(str) {
    const colors = [
        '#667eea', '#764ba2', '#f093fb', '#4facfe',
        '#43e97b', '#fa709a', '#fee140', '#30cfd0',
        '#a8edea', '#fed6e3', '#f78ca0', '#f9748f'
    ];
    
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    
    return colors[Math.abs(hash) % colors.length];
}

// Render channel item
function renderChannelItem(channel, isActive = false) {
    const icon = channel.channel_type === 'private' ? 'fa-lock' : 'fa-hashtag';
    
    return `
        <div class="channel-item ${isActive ? 'active' : ''}" 
             onclick="selectChannel('${channel.id}')"
             data-channel-id="${channel.id}">
            <i class="fas ${icon}"></i>
            <span>${escapeHTML(channel.name)}</span>
            ${channel.unread_count > 0 ? `<span class="unread-badge">${channel.unread_count}</span>` : ''}
        </div>
    `;
}

// Load channels to sidebar
function loadChannelsToSidebar(channels) {
    const channelsList = document.getElementById('channelsList');
    
    if (!channels || channels.length === 0) {
        channelsList.innerHTML = '<div class="empty-state">No channels</div>';
        return;
    }
    
    const currentChannelId = APP_STATE.currentChannel?.id;
    
    channelsList.innerHTML = channels
        .filter(ch => ch.channel_type === 'public' || ch.channel_type === 'private')
        .map(ch => renderChannelItem(ch, ch.id === currentChannelId))
        .join('');
}

// Load messages
async function loadMessages(channelId) {
    showLoading(true);
    
    try {
        const messages = await api.getMessages(channelId);
        
        const container = document.getElementById('messagesContainer');
        container.innerHTML = '';
        
        messages.forEach(msg => addMessageToUI(msg));
        
    } catch (error) {
        console.error('Error loading messages:', error);
        showToast('Failed to load messages', 'error');
    } finally {
        showLoading(false);
    }
}

// Show create channel modal
function showCreateChannel() {
    showModal('Create Channel', `
        <form id="createChannelForm">
            <div class="form-group">
                <label>Channel Name</label>
                <input type="text" id="channelName" required placeholder="e.g., marketing">
            </div>
            
            <div class="form-group">
                <label>Description (optional)</label>
                <textarea id="channelDescription" rows="3"></textarea>
            </div>
            
            <div class="form-group">
                <label>
                    <input type="checkbox" id="channelPrivate">
                    Make this channel private
                </label>
            </div>
            
            <button type="submit" class="btn btn-primary btn-block">
                <i class="fas fa-plus"></i> Create Channel
            </button>
        </form>
    `);
    
    document.getElementById('createChannelForm').onsubmit = async (e) => {
        e.preventDefault();
        
        const data = {
            workspace: APP_STATE.currentWorkspace.id,
            name: document.getElementById('channelName').value,
            description: document.getElementById('channelDescription').value,
            channel_type: document.getElementById('channelPrivate').checked ? 'private' : 'public'
        };
        
        try {
            const channel = await api.createChannel(data);
            showToast('Channel created successfully!', 'success');
            closeModal();
            
            // Reload channels
            await loadWorkspaceData(APP_STATE.currentWorkspace.id);
            
            // Select new channel
            selectChannel(channel.id);
            
        } catch (error) {
            console.error('Error creating channel:', error);
            showToast('Failed to create channel', 'error');
        }
    };
}

// Show modal
function showModal(title, content) {
    const modalContainer = document.getElementById('modalContainer');
    
    modalContainer.innerHTML = `
        <div class="modal-overlay" onclick="closeModal()">
            <div class="modal" onclick="event.stopPropagation()">
                <div class="modal-header">
                    <h3>${title}</h3>
                    <button class="btn-icon" onclick="closeModal()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    ${content}
                </div>
            </div>
        </div>
    `;
    
    modalContainer.style.display = 'block';
}

// Close modal
function closeModal() {
    const modalContainer = document.getElementById('modalContainer');
    modalContainer.style.display = 'none';
    modalContainer.innerHTML = '';
}

// Show user menu
function showUserMenu() {
    showModal('Account', `
        <div class="user-menu">
            <div class="user-info-card">
                <div class="user-avatar large">
                    ${getUserInitials(APP_STATE.user.full_name || APP_STATE.user.username)}
                </div>
                <h3>${escapeHTML(APP_STATE.user.full_name || APP_STATE.user.username)}</h3>
                <p>${escapeHTML(APP_STATE.user.email)}</p>
            </div>
            
            <div class="menu-actions">
                <button class="btn btn-block" onclick="showProfile()">
                    <i class="fas fa-user"></i> Edit Profile
                </button>
                <button class="btn btn-block" onclick="showSettings()">
                    <i class="fas fa-cog"></i> Settings
                </button>
                <button class="btn btn-danger btn-block" onclick="auth.logout()">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </button>
            </div>
        </div>
    `);
}

// Placeholder functions
function showProfile() { showToast('Profile feature coming soon!', 'info'); closeModal(); }
function showSettings() { showToast('Settings feature coming soon!', 'info'); closeModal(); }
function showNewDM() { showToast('Direct messages coming soon!', 'info'); }
function showFileUpload() { showToast('File upload coming soon!', 'info'); }
function showEmoji() { showToast('Emoji picker coming soon!', 'info'); }
function replyToMessage(id) { showToast('Thread reply coming soon!', 'info'); }
function addReaction(id) { 
    // Quick emoji reactions
    const emojis = ['👍', '❤️', '😂', '😮', '😢', '👏'];
    const emoji = prompt('Choose emoji: ' + emojis.join(' '));
    if (emoji) {
        wsManager.sendReaction(id, emoji);
    }
}
function toggleReaction(messageId, emoji) {
    wsManager.sendReaction(messageId, emoji);
}
function showMessageMenu(id) { showToast('Message menu coming soon!', 'info'); }

console.log('✅ UI helper loaded');

// Update addMessageToUI to include thread button
const originalAddMessage = addMessageToUI;
addMessageToUI = function(message) {
    const container = document.getElementById('messagesContainer');
    
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message';
    messageDiv.dataset.messageId = message.id;
    
    const user = message.user;
    const initials = getUserInitials(user.full_name || user.username);
    
    // Thread button if has replies
    const threadButton = message.reply_count > 0 ? 
        ThreadManager.addReplyButton(message.id, message.reply_count) : '';
    
    messageDiv.innerHTML = `
        <div class="message-avatar" style="background: ${generateColorFromString(user.id)}">
            ${initials}
        </div>
        <div class="message-content">
            <div class="message-header">
                <span class="message-author">${escapeHTML(user.full_name || user.username)}</span>
                <span class="message-time">${formatTime(message.created_at)}</span>
            </div>
            <div class="message-text">${formatMessageText(message.text)}</div>
            ${message.reactions && message.reactions.length > 0 ? renderReactions(message.reactions) : ''}
            <div class="message-actions">
                ${threadButton}
                <button class="btn-icon" onclick="replyToMessage('${message.id}')" title="Reply in thread">
                    <i class="fas fa-reply"></i>
                </button>
                <button class="btn-icon" onclick="addReaction('${message.id}')" title="Add reaction">
                    <i class="fas fa-smile"></i>
                </button>
                <button class="btn-icon" onclick="showMessageMenu('${message.id}')" title="More">
                    <i class="fas fa-ellipsis-v"></i>
                </button>
            </div>
        </div>
    `;
    
    container.appendChild(messageDiv);
    container.scrollTop = container.scrollHeight;
};

// Update addMessageToUI to include data attributes
const _originalAddMessageToUI = addMessageToUI;
addMessageToUI = function(message) {
    const container = document.getElementById('messagesContainer');
    
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message';
    messageDiv.dataset.messageId = message.id;
    
    const user = message.user;
    const initials = getUserInitials(user.full_name || user.username);
    
    // Thread button if has replies
    const threadButton = message.reply_count > 0 ? 
        ThreadManager.addReplyButton(message.id, message.reply_count) : '';
    
    messageDiv.innerHTML = `
        <div class="message-avatar" 
             data-user-id="${user.id}"
             style="background: ${generateColorFromString(user.id)}">
            ${initials}
        </div>
        <div class="message-content">
            <div class="message-header">
                <span class="message-author">${escapeHTML(user.full_name || user.username)}</span>
                <span class="message-time" data-timestamp="${message.created_at}">
                    ${formatTime(message.created_at)}
                </span>
            </div>
            <div class="message-text">
                ${formatMessageText(message.text)}
                ${message.is_edited ? '<span class="edited">(edited)</span>' : ''}
            </div>
            ${message.reactions && message.reactions.length > 0 ? renderReactions(message.reactions) : ''}
            <div class="message-actions">
                ${threadButton}
                <button class="btn-icon" onclick="replyToMessage('${message.id}')" title="Reply in thread">
                    <i class="fas fa-reply"></i>
                </button>
                <button class="btn-icon" onclick="addReaction('${message.id}')" title="Add reaction">
                    <i class="fas fa-smile"></i>
                </button>
                <button class="btn-icon" onclick="showMessageMenu('${message.id}')" title="More">
                    <i class="fas fa-ellipsis-v"></i>
                </button>
            </div>
        </div>
    `;
    
    container.appendChild(messageDiv);
    container.scrollTop = container.scrollHeight;
};

// Update showUserMenu to include theme option
const _originalShowUserMenu = showUserMenu;
showUserMenu = function() {
    showModal('Account', `
        <div class="user-menu">
            <div class="user-info-card">
                <div class="user-avatar large" style="background: ${generateColorFromString(APP_STATE.user.id)}">
                    ${getUserInitials(APP_STATE.user.full_name || APP_STATE.user.username)}
                </div>
                <h3>${escapeHTML(APP_STATE.user.full_name || APP_STATE.user.username)}</h3>
                <p>${escapeHTML(APP_STATE.user.email)}</p>
            </div>
            
            <div class="menu-actions">
                <button class="btn btn-block" onclick="showProfile()">
                    <i class="fas fa-user"></i> Edit Profile
                </button>
                <button class="btn btn-block" onclick="themeManager.showSelector(); closeModal();">
                    <i class="fas fa-palette"></i> Theme
                    <span style="float: right; font-size: 12px; opacity: 0.7;">
                        ${themeManager.getTheme() === 'dark' ? '🌙 Dark' : '☀️ Light'}
                    </span>
                </button>
                <button class="btn btn-block" onclick="showSettings()">
                    <i class="fas fa-cog"></i> Settings
                </button>
                <button class="btn btn-danger btn-block" onclick="auth.logout()">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </button>
            </div>
        </div>
    `);
};

// Update showUserMenu to include status
const __originalShowUserMenu = showUserMenu;
showUserMenu = function() {
    showModal('Account', `
        <div class="user-menu">
            <div class="user-info-card">
                <div class="user-avatar large" style="background: ${generateColorFromString(APP_STATE.user.id)}">
                    ${APP_STATE.user.profile?.avatar ? 
                        `<img src="${APP_STATE.user.profile.avatar}" alt="Avatar">` :
                        getUserInitials(APP_STATE.user.full_name || APP_STATE.user.username)
                    }
                </div>
                <h3>${escapeHTML(APP_STATE.user.full_name || APP_STATE.user.username)}</h3>
                <p>${escapeHTML(APP_STATE.user.email)}</p>
            </div>
            
            <div class="menu-actions">
                <button class="btn btn-block" onclick="profileManager.showStatusEditor(); closeModal();">
                    <i class="fas fa-circle" style="color: #10b981;"></i> Set Status
                </button>
                <button class="btn btn-block" onclick="showProfile()">
                    <i class="fas fa-user"></i> Edit Profile
                </button>
                <button class="btn btn-block" onclick="themeManager.showSelector(); closeModal();">
                    <i class="fas fa-palette"></i> Theme
                    <span style="float: right; font-size: 12px; opacity: 0.7;">
                        ${themeManager.getTheme() === 'dark' ? '🌙 Dark' : '☀️ Light'}
                    </span>
                </button>
                <button class="btn btn-block" onclick="showSettings()">
                    <i class="fas fa-cog"></i> Settings
                </button>
                <button class="btn btn-danger btn-block" onclick="auth.logout()">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </button>
            </div>
        </div>
    `);
};
