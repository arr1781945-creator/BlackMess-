// API Configuration
const API_BASE_URL = 'http://localhost:8000/api';
const WS_BASE_URL = 'ws://localhost:8000/ws';

// App State
const STATE = {
    user: null,
    workspace: null,
    channels: [],
    currentChannel: null,
    messages: [],
    ws: null,
    isConnected: false
};

// Token Management
function getToken() {
    return localStorage.getItem('access_token');
}

function setToken(token) {
    localStorage.setItem('access_token', token);
}

function clearToken() {
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    localStorage.removeItem('user');
    localStorage.removeItem('workspace');
}

// User Management
function getStoredUser() {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
}

function storeUser(user) {
    localStorage.setItem('user', JSON.stringify(user));
    STATE.user = user;
}

// Workspace Management
function getStoredWorkspace() {
    const ws = localStorage.getItem('workspace');
    return ws ? JSON.parse(ws) : null;
}

function storeWorkspace(workspace) {
    localStorage.setItem('workspace', JSON.stringify(workspace));
    STATE.workspace = workspace;
}

// Auth Check
function isAuthenticated() {
    return !!getToken();
}

// Toast Notification System
function showNotification(message, type = 'info') {
    // Remove existing toasts
    const existing = document.querySelectorAll('.toast');
    existing.forEach(t => t.remove());
    
    // Create toast
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    const icon = {
        'success': '✓',
        'error': '✕',
        'warning': '⚠',
        'info': 'ℹ'
    }[type] || 'ℹ';
    
    toast.innerHTML = `
        <span class="toast-icon">${icon}</span>
        <span class="toast-message">${message}</span>
    `;
    
    // Add to page
    document.body.appendChild(toast);
    
    // Show
    setTimeout(() => toast.classList.add('show'), 10);
    
    // Auto-hide after 3 seconds
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Time Formatting
function formatTime(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    
    // Less than 1 minute
    if (diff < 60000) return 'Just now';
    
    // Less than 1 hour
    if (diff < 3600000) {
        const mins = Math.floor(diff / 60000);
        return `${mins} min${mins > 1 ? 's' : ''} ago`;
    }
    
    // Today
    if (date.toDateString() === now.toDateString()) {
        return date.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
    }
    
    // This week
    if (diff < 7 * 24 * 60 * 60 * 1000) {
        return date.toLocaleDateString('en-US', { 
            weekday: 'short', 
            hour: '2-digit', 
            minute: '2-digit' 
        });
    }
    
    // This year
    if (date.getFullYear() === now.getFullYear()) {
        return date.toLocaleDateString('en-US', { 
            month: 'short', 
            day: 'numeric' 
        });
    }
    
    // Other years
    return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
    });
}

// HTML Escape
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Add Toast CSS
const toastStyles = document.createElement('style');
toastStyles.textContent = `
.toast {
    position: fixed;
    top: 20px;
    right: 20px;
    background: white;
    padding: 16px 20px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    display: flex;
    align-items: center;
    gap: 12px;
    min-width: 250px;
    opacity: 0;
    transform: translateX(400px);
    transition: all 0.3s ease;
    z-index: 10000;
}

.toast.show {
    opacity: 1;
    transform: translateX(0);
}

.toast-icon {
    font-size: 20px;
    font-weight: 700;
}

.toast-success { border-left: 4px solid #2BAC76; }
.toast-success .toast-icon { color: #2BAC76; }

.toast-error { border-left: 4px solid #E01E5A; }
.toast-error .toast-icon { color: #E01E5A; }

.toast-warning { border-left: 4px solid #ECB22E; }
.toast-warning .toast-icon { color: #ECB22E; }

.toast-info { border-left: 4px solid #1264A3; }
.toast-info .toast-icon { color: #1264A3; }

.toast-message {
    flex: 1;
    font-size: 14px;
    color: #1D1C1D;
}
`;
document.head.appendChild(toastStyles);

console.log('✅ Config loaded (full version)');
