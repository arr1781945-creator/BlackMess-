// WebSocket connection
let ws = null;
let reconnectInterval = null;

async function loadApp() {
    const workspace = getStoredWorkspace();
    const user = getStoredUser();
    
    if (!workspace || !user) {
        showLogin();
        return;
    }
    
    // Update UI
    document.getElementById('currentWorkspaceName').textContent = workspace.name;
    document.getElementById('currentWorkspaceBtn').textContent = workspace.name.charAt(0).toUpperCase();
    document.getElementById('userName').textContent = user.first_name || user.username;
    document.getElementById('userAvatar').textContent = (user.first_name || user.username).charAt(0).toUpperCase();
    
    await loadChannels();
    showMainApp();
    generateInviteLink();
}

async function loadChannels() {
    try {
        const workspace = getStoredWorkspace();
        const channels = await API.getChannels(workspace.id);
        STATE.channels = channels || [];
        
        const list = document.getElementById('channelList');
        list.innerHTML = '';
        
        if (channels && channels.length > 0) {
            channels.forEach(ch => {
                const item = document.createElement('div');
                item.className = 'channel-item';
                item.innerHTML = `<span class="icon-hashtag"></span><span>${ch.name}</span>`;
                item.onclick = () => switchChannel(ch);
                list.appendChild(item);
            });
            
            if (!STATE.currentChannel) {
                switchChannel(channels[0]);
            }
        } else {
            // Create default channel
            const defaultChannel = await API.createChannel(workspace.id, 'general', 'General discussion');
            await loadChannels();
        }
    } catch (error) {
        console.error('Load channels error:', error);
        showNotification('Failed to load channels', 'error');
    }
}

async function switchChannel(channel) {
    STATE.currentChannel = channel;
    document.getElementById('currentChannelName').textContent = channel.name;
    
    // Update active state
    document.querySelectorAll('.channel-item').forEach(i => i.classList.remove('active'));
    if (event && event.target) {
        event.target.closest('.channel-item').classList.add('active');
    }
    
    // Load messages
    await loadMessages(channel.id);
    
    // Connect WebSocket
    connectWebSocket(channel.id);
}

async function loadMessages(channelId) {
    try {
        const result = await API.getMessages(channelId);
        STATE.messages = result.results || [];
        renderMessages(STATE.messages);
    } catch (error) {
        console.error('Load messages error:', error);
        document.getElementById('messagesContainer').innerHTML = '<div class="loading">Failed to load messages</div>';
    }
}

function renderMessages(messages) {
    const container = document.getElementById('messagesContainer');
    
    if (messages.length === 0) {
        container.innerHTML = '<div class="loading">No messages yet. Start the conversation!</div>';
        return;
    }
    
    container.innerHTML = messages.map(msg => `
        <div class="message" data-id="${msg.id}">
            <div class="message-avatar">${(msg.user?.first_name || 'U').charAt(0).toUpperCase()}</div>
            <div class="message-content">
                <div class="message-header">
                    <span class="message-author">${msg.user?.first_name || msg.user?.username || 'User'}</span>
                    <span class="message-time">${formatTime(msg.created_at)}</span>
                </div>
                <div class="message-text">${escapeHtml(msg.content)}</div>
            </div>
        </div>
    `).join('');
    
    // Scroll to bottom
    container.scrollTop = container.scrollHeight;
}

async function sendMessage() {
    const input = document.getElementById('messageInput');
    const content = input.value.trim();
    
    if (!content || !STATE.currentChannel) return;
    
    try {
        const message = await API.sendMessage(STATE.currentChannel.id, content);
        input.value = '';
        
        // Add to local state (WebSocket will also send it)
        STATE.messages.push(message);
        renderMessages(STATE.messages);
        
    } catch (error) {
        console.error('Send message error:', error);
        showNotification('Failed to send message', 'error');
    }
}

// WebSocket Functions
function connectWebSocket(channelId) {
    // Close existing connection
    if (ws) {
        ws.close();
        ws = null;
    }
    
    // Clear reconnect interval
    if (reconnectInterval) {
        clearInterval(reconnectInterval);
        reconnectInterval = null;
    }
    
    try {
        const token = getToken();
        const wsUrl = `ws://localhost:8000/ws/chat/${channelId}/?token=${token}`;
        
        ws = new WebSocket(wsUrl);
        
        ws.onopen = () => {
            console.log('✅ WebSocket connected');
            STATE.isConnected = true;
        };
        
        ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            handleWebSocketMessage(data);
        };
        
        ws.onclose = () => {
            console.log('❌ WebSocket disconnected');
            STATE.isConnected = false;
            
            // Auto-reconnect after 3 seconds
            if (STATE.currentChannel) {
                reconnectInterval = setTimeout(() => {
                    console.log('🔄 Reconnecting WebSocket...');
                    connectWebSocket(channelId);
                }, 3000);
            }
        };
        
        ws.onerror = (error) => {
            console.error('WebSocket error:', error);
        };
        
    } catch (error) {
        console.error('WebSocket connection error:', error);
    }
}

function handleWebSocketMessage(data) {
    console.log('WebSocket message:', data);
    
    switch (data.type) {
        case 'message':
            // Check if message already exists
            const exists = STATE.messages.find(m => m.id === data.message.id);
            if (!exists) {
                STATE.messages.push(data.message);
                renderMessages(STATE.messages);
            }
            break;
            
        case 'typing':
            console.log(`${data.user} is typing...`);
            // TODO: Show typing indicator
            break;
            
        case 'user_online':
            console.log(`${data.user} is online`);
            // TODO: Update user status
            break;
            
        default:
            console.log('Unknown message type:', data.type);
    }
}

// Channel Management
function showCreateChannel() {
    document.getElementById('createChannelModal').classList.remove('hidden');
}

function closeCreateChannel() {
    document.getElementById('createChannelModal').classList.add('hidden');
}

document.getElementById('createChannelForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const name = document.getElementById('channelName').value;
    const desc = document.getElementById('channelDesc').value;
    const workspace = getStoredWorkspace();
    
    try {
        await API.createChannel(workspace.id, name, desc);
        showNotification('Channel created!', 'success');
        closeCreateChannel();
        await loadChannels();
    } catch (error) {
        showNotification(error.message || 'Failed to create channel', 'error');
    }
});

// Invite Functions
function generateInviteLink() {
    const workspace = getStoredWorkspace();
    const inviteLink = `${window.location.origin}?invite=${workspace.id}`;
    document.getElementById('inviteLink').value = inviteLink;
}

function showInviteModal() {
    document.getElementById('inviteModal').classList.remove('hidden');
}

function closeInviteModal() {
    document.getElementById('inviteModal').classList.add('hidden');
}

function copyInviteLink() {
    const input = document.getElementById('inviteLink');
    input.select();
    document.execCommand('copy');
    showNotification('Invite link copied!', 'success');
}

// File Upload
async function handleFileUpload(event) {
    const file = event.target.files[0];
    if (!file || !STATE.currentChannel) return;
    
    // File size limit: 10MB
    if (file.size > 10 * 1024 * 1024) {
        showNotification('File too large. Max 10MB', 'error');
        return;
    }
    
    try {
        showNotification('Uploading file...', 'info');
        
        const result = await API.uploadFile(file, STATE.currentChannel.id);
        
        showNotification('File uploaded!', 'success');
        
        // Reload messages to show file
        await loadMessages(STATE.currentChannel.id);
        
    } catch (error) {
        console.error('File upload error:', error);
        showNotification(error.message || 'File upload failed', 'error');
    }
    
    // Reset input
    event.target.value = '';
}

// Message Input Enhancement
const messageInput = document.getElementById('messageInput');
if (messageInput) {
    // Auto-resize
    messageInput.addEventListener('input', () => {
        messageInput.style.height = 'auto';
        messageInput.style.height = Math.min(messageInput.scrollHeight, 200) + 'px';
    });
    
    // Send on Enter (Shift+Enter for new line)
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    // Typing indicator (WebSocket)
    let typingTimeout;
    messageInput.addEventListener('input', () => {
        if (ws && ws.readyState === WebSocket.OPEN) {
            clearTimeout(typingTimeout);
            
            ws.send(JSON.stringify({
                type: 'typing',
                user: getStoredUser().username
            }));
            
            typingTimeout = setTimeout(() => {
                ws.send(JSON.stringify({
                    type: 'stop_typing',
                    user: getStoredUser().username
                }));
            }, 1000);
        }
    });
}

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (ws) {
        ws.close();
    }
    if (reconnectInterval) {
        clearInterval(reconnectInterval);
    }
});

console.log('✅ App loaded (full version with WebSocket)');
