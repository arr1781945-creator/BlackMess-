const API = {
    async request(url, options = {}) {
        const token = getToken();
        const headers = { 'Content-Type': 'application/json', ...options.headers };
        if (token) headers['Authorization'] = `Bearer ${token}`;
        
        try {
            const response = await fetch(`${API_BASE_URL}${url}`, { ...options, headers });
            
            // Handle 401 - Token expired
            if (response.status === 401) {
                const refreshed = await this.refreshToken();
                if (refreshed) {
                    // Retry request dengan token baru
                    headers['Authorization'] = `Bearer ${getToken()}`;
                    const retryResponse = await fetch(`${API_BASE_URL}${url}`, { ...options, headers });
                    const retryData = await retryResponse.json();
                    if (!retryResponse.ok) throw new Error(retryData.error || 'Request failed');
                    return retryData;
                } else {
                    // Refresh failed, logout
                    clearToken();
                    window.location.reload();
                    return null;
                }
            }
            
            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.error || data.detail || `HTTP ${response.status}`);
            }
            return data;
            
        } catch (error) {
            console.error('API Error:', error);
            
            // Network error handling
            if (error.message === 'Failed to fetch') {
                showNotification('Network error. Please check your connection.', 'error');
            } else {
                showNotification(error.message, 'error');
            }
            throw error;
        }
    },
    
    async refreshToken() {
        const refresh = localStorage.getItem('refresh_token');
        if (!refresh) return false;
        
        try {
            const response = await fetch(`${API_BASE_URL}/auth/refresh/`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ refresh })
            });
            
            const data = await response.json();
            if (data.access) {
                setToken(data.access);
                return true;
            }
            return false;
        } catch (error) {
            console.error('Token refresh failed:', error);
            return false;
        }
    },
    
    async login(email, password) {
        const data = await this.request('/auth/login/', {
            method: 'POST',
            body: JSON.stringify({ email, password })
        });
        
        if (data.access) {
            setToken(data.access);
            localStorage.setItem('refresh_token', data.refresh);
            storeUser(data.user);
        }
        return data;
    },
    
    async register(name, email, password) {
        const [first_name, ...rest] = name.split(' ');
        return this.request('/auth/register/', {
            method: 'POST',
            body: JSON.stringify({
                username: email.split('@')[0],
                email,
                password,
                first_name,
                last_name: rest.join(' ')
            })
        });
    },
    
    async logout() {
        try {
            await this.request('/auth/logout/', { method: 'POST' });
        } catch (error) {
            console.error('Logout error:', error);
        } finally {
            clearToken();
            window.location.reload();
        }
    },
    
    async getWorkspaces() {
        return this.request('/workspaces/');
    },
    
    async createWorkspace(name, description) {
        return this.request('/workspaces/', {
            method: 'POST',
            body: JSON.stringify({
                name,
                description,
                slug: name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')
            })
        });
    },
    
    async getChannels(workspaceId) {
        return this.request(`/channels/?workspace=${workspaceId}`);
    },
    
    async createChannel(workspaceId, name, description, isPrivate = false) {
        return this.request('/channels/', {
            method: 'POST',
            body: JSON.stringify({
                workspace: workspaceId,
                name: name.toLowerCase().replace(/\s+/g, '-'),
                description,
                is_private: isPrivate
            })
        });
    },
    
    async getMessages(channelId, page = 1) {
        return this.request(`/messages/?channel=${channelId}&page=${page}&limit=50`);
    },
    
    async sendMessage(channelId, content, parentId = null) {
        return this.request('/messages/', {
            method: 'POST',
            body: JSON.stringify({
                channel: channelId,
                content,
                parent_message: parentId
            })
        });
    },
    
    async uploadFile(file, channelId) {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('channel', channelId);
        
        const token = getToken();
        const response = await fetch(`${API_BASE_URL}/files/upload/`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}` },
            body: formData
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Upload failed');
        }
        
        return response.json();
    },
    
    async searchMessages(query, channelId = null) {
        let url = `/messages/search/?q=${encodeURIComponent(query)}`;
        if (channelId) url += `&channel=${channelId}`;
        return this.request(url);
    }
};

console.log('✅ API loaded (full version)');
